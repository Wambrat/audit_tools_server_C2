# -----------------------------------------------------------------------------
# Fonction : Get-ADAccountSecurityAudit
# Description : Controles ANSSI AD-13 a AD-22 - politiques de mots de passe du
#               domaine et attributs userAccountControl dangereux.
# Referentiel : ANSSI "Points de controle Active Directory" et guide
#               "Recommandations relatives a l'authentification multifacteur
#               et aux mots de passe" (2021).
# -----------------------------------------------------------------------------

function Get-ADAccountSecurityAudit {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$Context,

        # Longueurs minimales ANSSI par population de comptes
        [int]$MinLengthStandard = 12,
        [int]$MinLengthPrivileged = 15,
        [int]$MinLengthService = 32,
        [int]$MaxLockoutThreshold = 10
    )

    $results = @()
    $srv = $Context.Server
    $cat = "Authentification et mots de passe"

    # Filtre LDAP restreint aux comptes utilisateurs actives (hors comptes machine)
    $enabledUserFilter = "(&(objectCategory=person)(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))"

    function Get-UserAccountsByUacBit {
        param([int]$Bit)
        try {
            return @(Get-ADUser -LDAPFilter "(&$enabledUserFilter(userAccountControl:1.2.840.113556.1.4.803:=$Bit))" `
                        -Server $srv -Properties sAMAccountName, userAccountControl -ErrorAction Stop)
        }
        catch { return $null }
    }

    # --- Politique de mot de passe par defaut du domaine ---------------------
    $policy = $null
    try { $policy = Get-ADDefaultDomainPasswordPolicy -Server $srv -ErrorAction Stop } catch { }

    # =========================================================================
    # AD-13 : Longueur minimale des mots de passe
    # =========================================================================
    if ($policy) {
        $len = [int]$policy.MinPasswordLength
        $status = if ($len -ge $MinLengthStandard) { "PASS" } elseif ($len -ge 8) { "WARNING" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-13" -Name "DomainPasswordMinLength" `
            -Title "Longueur minimale des mots de passe de la politique de domaine" `
            -Category $cat -AnssiRef "ANSSI vuln2_password_length / Guide mots de passe R1" `
            -Severity "Majeur" -Status $status `
            -Comment "Longueur minimale configuree : $len caracteres (attendu : $MinLengthStandard)." `
            -Recommendation "Porter la longueur minimale a $MinLengthStandard caracteres pour les comptes standard (avec verrouillage de compte) et $MinLengthPrivileged caracteres pour les comptes a privileges via une strategie affinee." `
            -Details "MinPasswordLength=$len ; MinPasswordAge=$($policy.MinPasswordAge) ; MaxPasswordAge=$($policy.MaxPasswordAge) ; PasswordHistoryCount=$($policy.PasswordHistoryCount)"
    }
    else {
        $results += New-ADCheckResult -CheckId "AD-13" -Name "DomainPasswordMinLength" `
            -Title "Longueur minimale des mots de passe de la politique de domaine" `
            -Category $cat -AnssiRef "ANSSI vuln2_password_length" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Politique de mot de passe du domaine illisible." `
            -Recommendation "Verifier la connectivite avec un controleur de domaine et les droits de lecture."
    }

    # =========================================================================
    # AD-14 : Complexite des mots de passe
    # =========================================================================
    if ($policy) {
        $complexity = [bool]$policy.ComplexityEnabled
        $status = if ($complexity) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-14" -Name "DomainPasswordComplexity" `
            -Title "Exigence de complexite des mots de passe" `
            -Category $cat -AnssiRef "ANSSI vuln2_password_complexity" -Severity "Majeur" -Status $status `
            -Comment "Complexite des mots de passe : $(if ($complexity) { 'activee' } else { 'desactivee' })." `
            -Recommendation "Activer l'exigence de complexite dans la politique de domaine ; elle reste necessaire tant que la longueur minimale n'atteint pas les recommandations de l'ANSSI." `
            -Details "ComplexityEnabled=$complexity"
    }

    # =========================================================================
    # AD-15 : Politique de verrouillage des comptes
    # =========================================================================
    if ($policy) {
        $threshold = [int]$policy.LockoutThreshold
        $status = "PASS"
        $comment = "Seuil de verrouillage : $threshold tentative(s), duree $($policy.LockoutDuration), fenetre d'observation $($policy.LockoutObservationWindow)."

        if ($threshold -eq 0) {
            $status = "FAIL"
            $comment = "Aucun verrouillage de compte configure (seuil = 0) : attaques par force brute non entravees."
        }
        elseif ($threshold -gt $MaxLockoutThreshold) {
            $status = "WARNING"
        }

        $results += New-ADCheckResult -CheckId "AD-15" -Name "DomainAccountLockoutPolicy" `
            -Title "Politique de verrouillage des comptes du domaine" `
            -Category $cat -AnssiRef "ANSSI vuln2_account_lockout" -Severity "Majeur" -Status $status `
            -Comment $comment `
            -Recommendation "Configurer un verrouillage de compte apres $MaxLockoutThreshold echecs au maximum, avec une duree de verrouillage et une fenetre d'observation d'au moins 15 minutes." `
            -Details "LockoutThreshold=$threshold ; LockoutDuration=$($policy.LockoutDuration) ; LockoutObservationWindow=$($policy.LockoutObservationWindow)"
    }

    # =========================================================================
    # AD-16 : Strategies de mot de passe affinees (PSO) pour les comptes a privileges
    # =========================================================================
    try {
        $psos = @(Get-ADFineGrainedPasswordPolicy -Filter * -Server $srv -ErrorAction Stop)

        # Les PSO sont rattachees a une population d'apres leur nom : c'est la
        # convention retenue faute de marqueur normalise dans l'annuaire.
        $privilegedPsos = @($psos | Where-Object { $_.Name -match "Admin|Priv|Root|Tier|T0" })
        $servicePsos    = @($psos | Where-Object { $_.Name -match "Service|Svc|App|GMSA" })

        # Ecarts par rapport aux seuils ANSSI, par population
        $gaps = @()
        foreach ($p in $privilegedPsos) {
            if ([int]$p.MinPasswordLength -lt $MinLengthPrivileged) {
                $gaps += "$($p.Name) [privilegie] : longueur $($p.MinPasswordLength) < $MinLengthPrivileged"
            }
            if ($p.MaxPasswordAge -eq [TimeSpan]::Zero) {
                $gaps += "$($p.Name) [privilegie] : pas de rotation forcee"
            }
        }
        foreach ($p in $servicePsos) {
            if ([int]$p.MinPasswordLength -lt $MinLengthService) {
                $gaps += "$($p.Name) [service] : longueur $($p.MinPasswordLength) < $MinLengthService"
            }
        }

        $strongPsos = @($psos | Where-Object { [int]$_.MinPasswordLength -ge $MinLengthPrivileged })

        $status = "FAIL"
        $comment = "Aucune strategie de mot de passe affinee definie."

        if ($psos.Count -gt 0 -and $strongPsos.Count -gt 0 -and $gaps.Count -eq 0) {
            $status = "PASS"
            $comment = "$($psos.Count) PSO definie(s), dont $($strongPsos.Count) imposant au moins $MinLengthPrivileged caracteres ; aucun ecart par population."
        }
        elseif ($psos.Count -gt 0) {
            $status = "WARNING"
            $comment = "$($psos.Count) PSO definie(s) ($($privilegedPsos.Count) privilegiee(s), $($servicePsos.Count) service) avec $($gaps.Count) ecart(s) par rapport aux seuils ANSSI."
        }

        $results += New-ADCheckResult -CheckId "AD-16" -Name "FineGrainedPasswordPolicies" `
            -Title "Strategies de mot de passe affinees pour les comptes a privileges" `
            -Category $cat -AnssiRef "ANSSI vuln3_no_pso / DAT-NT-017" -Severity "Majeur" -Status $status `
            -Comment $comment `
            -Recommendation "Definir des PSO couvrant les groupes d'administration ($MinLengthPrivileged caracteres minimum, avec rotation forcee) et les comptes de service ($MinLengthService caracteres generes aleatoirement) : la politique de domaine par defaut ne suffit pas pour ces populations." `
            -Details ($gaps + @($psos | ForEach-Object { "$($_.Name) (longueur=$($_.MinPasswordLength), rotation=$($_.MaxPasswordAge), precedence=$($_.Precedence))" })) `
            -AffectedCount $psos.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-16" -Name "FineGrainedPasswordPolicies" `
            -Title "Strategies de mot de passe affinees pour les comptes a privileges" `
            -Category $cat -AnssiRef "ANSSI vuln3_no_pso" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Lecture des PSO impossible : $($_.Exception.Message)" `
            -Recommendation "Executer l'audit avec un compte autorise a lire le conteneur Password Settings."
    }

    # =========================================================================
    # AD-17 : Comptes sans mot de passe requis (PASSWD_NOTREQD)
    # =========================================================================
    $noPwdRequired = Get-UserAccountsByUacBit -Bit 32
    if ($null -ne $noPwdRequired) {
        $status = if ($noPwdRequired.Count -eq 0) { "PASS" } else { "FAIL" }
        $results += New-ADCheckResult -CheckId "AD-17" -Name "PasswordNotRequiredAccounts" `
            -Title "Comptes actifs dispenses de mot de passe (PASSWD_NOTREQD)" `
            -Category $cat -AnssiRef "ANSSI vuln1_no_password_required" -Severity "Critique" -Status $status `
            -Comment "$($noPwdRequired.Count) compte(s) actif(s) portent l'indicateur PASSWD_NOTREQD." `
            -Recommendation "Retirer l'indicateur PASSWD_NOTREQD et definir un mot de passe conforme : ces comptes peuvent posseder un mot de passe vide et etre utilises sans authentification reelle." `
            -Details @($noPwdRequired | ForEach-Object { $_.sAMAccountName }) -AffectedCount $noPwdRequired.Count
    }

    # =========================================================================
    # AD-18 : Comptes a mot de passe sans expiration (DONT_EXPIRE_PASSWORD)
    # =========================================================================
    $neverExpires = Get-UserAccountsByUacBit -Bit 65536
    if ($null -ne $neverExpires) {
        $status = if ($neverExpires.Count -eq 0) { "PASS" } elseif ($neverExpires.Count -le 5) { "WARNING" } else { "FAIL" }
        $results += New-ADCheckResult -CheckId "AD-18" -Name "PasswordNeverExpiresAccounts" `
            -Title "Comptes actifs dont le mot de passe n'expire jamais" `
            -Category $cat -AnssiRef "ANSSI vuln2_password_never_expires" -Severity "Majeur" -Status $status `
            -Comment "$($neverExpires.Count) compte(s) actif(s) avec un mot de passe qui n'expire jamais." `
            -Recommendation "Limiter cet indicateur aux seuls comptes de service dont le secret est gere et renouvele par ailleurs (gMSA de preference), et le retirer de tous les comptes nominatifs." `
            -Details @($neverExpires | ForEach-Object { $_.sAMAccountName }) -AffectedCount $neverExpires.Count
    }

    # =========================================================================
    # AD-19 : Chiffrement reversible des mots de passe
    # =========================================================================
    $reversible = Get-UserAccountsByUacBit -Bit 128
    $policyReversible = $false
    if ($policy -and $null -ne $policy.ReversibleEncryptionEnabled) {
        $policyReversible = [bool]$policy.ReversibleEncryptionEnabled
    }

    if ($null -ne $reversible) {
        $status = if ($reversible.Count -eq 0 -and -not $policyReversible) { "PASS" } else { "FAIL" }
        $comment = "$($reversible.Count) compte(s) avec chiffrement reversible ; politique de domaine : $(if ($policyReversible) { 'activee' } else { 'desactivee' })."

        $results += New-ADCheckResult -CheckId "AD-19" -Name "ReversiblePasswordEncryption" `
            -Title "Stockage des mots de passe avec chiffrement reversible" `
            -Category $cat -AnssiRef "ANSSI vuln1_reversible_password" -Severity "Critique" -Status $status `
            -Comment $comment `
            -Recommendation "Desactiver le stockage des mots de passe avec chiffrement reversible dans la politique de domaine et sur les comptes concernes, puis forcer le renouvellement de ces mots de passe (ils sont recuperables en clair)." `
            -Details @($reversible | ForEach-Object { $_.sAMAccountName }) -AffectedCount $reversible.Count
    }

    # =========================================================================
    # AD-20 : Interdiction du stockage des empreintes LM
    # =========================================================================
    $noLmHash = $null
    $lmSource = ""
    $defaultDomainPolicyGuid = "{31B2F340-016D-11D2-945F-00C04FB984F9}"

    $tmpl = Get-ADGpoSecurityTemplate -Context $Context -GpoGuid $defaultDomainPolicyGuid
    if ($tmpl -and $tmpl.ContainsKey("Registry Values")) {
        foreach ($k in $tmpl["Registry Values"].Keys) {
            if ($k -like "*\Lsa\NoLMHash") {
                # Format : 4,<valeur>
                $parts = "$($tmpl['Registry Values'][$k])" -split ','
                $noLmHash = [int]($parts[-1].Trim())
                $lmSource = "Default Domain Policy"
            }
        }
    }

    if ($null -eq $noLmHash) {
        try {
            $reg = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "NoLMHash" -ErrorAction Stop
            $noLmHash = [int]$reg.NoLMHash
            $lmSource = "registre local ($env:COMPUTERNAME)"
        }
        catch { }
    }

    if ($null -eq $noLmHash) {
        $results += New-ADCheckResult -CheckId "AD-20" -Name "NoLMHashStorage" `
            -Title "Interdiction du stockage des empreintes LM" `
            -Category $cat -AnssiRef "ANSSI vuln2_lm_hash" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Parametre NoLMHash introuvable dans la Default Domain Policy et dans le registre local." `
            -Recommendation "Definir 'Securite reseau : ne pas stocker de valeurs de hachage de niveau LAN Manager' sur Active dans une GPO appliquee a l'ensemble du domaine."
    }
    else {
        $status = if ($noLmHash -eq 1) { "PASS" } else { "FAIL" }
        $results += New-ADCheckResult -CheckId "AD-20" -Name "NoLMHashStorage" `
            -Title "Interdiction du stockage des empreintes LM" `
            -Category $cat -AnssiRef "ANSSI vuln2_lm_hash" -Severity "Majeur" -Status $status `
            -Comment "NoLMHash = $noLmHash (source : $lmSource)." `
            -Recommendation "Positionner NoLMHash a 1 par GPO : les empreintes LM sont cassables en quelques minutes." `
            -Details "Source : $lmSource"
    }

    # =========================================================================
    # AD-21 : Comptes restreints au chiffrement DES
    # =========================================================================
    $desOnly = Get-UserAccountsByUacBit -Bit 2097152
    if ($null -ne $desOnly) {
        $status = if ($desOnly.Count -eq 0) { "PASS" } else { "FAIL" }
        $results += New-ADCheckResult -CheckId "AD-21" -Name "DesOnlyAccounts" `
            -Title "Comptes limites au chiffrement Kerberos DES" `
            -Category $cat -AnssiRef "ANSSI vuln2_des_enabled" -Severity "Majeur" -Status $status `
            -Comment "$($desOnly.Count) compte(s) actif(s) restreint(s) au chiffrement DES." `
            -Recommendation "Retirer l'indicateur USE_DES_KEY_ONLY et basculer ces comptes sur AES : DES est casse et n'offre plus aucune garantie." `
            -Details @($desOnly | ForEach-Object { $_.sAMAccountName }) -AffectedCount $desOnly.Count
    }

    # =========================================================================
    # AD-22 : Comptes sans pre-authentification Kerberos (AS-REP roasting)
    # =========================================================================
    $noPreAuth = Get-UserAccountsByUacBit -Bit 4194304
    if ($null -ne $noPreAuth) {
        $status = if ($noPreAuth.Count -eq 0) { "PASS" } else { "FAIL" }
        $results += New-ADCheckResult -CheckId "AD-22" -Name "KerberosPreAuthDisabled" `
            -Title "Comptes sans pre-authentification Kerberos (AS-REP roasting)" `
            -Category $cat -AnssiRef "ANSSI vuln2_kerberos_preauth" -Severity "Critique" -Status $status `
            -Comment "$($noPreAuth.Count) compte(s) actif(s) sans pre-authentification Kerberos." `
            -Recommendation "Reactiver la pre-authentification Kerberos sur ces comptes : sans elle, un attaquant non authentifie obtient un materiel chiffre avec le mot de passe du compte et le casse hors ligne." `
            -Details @($noPreAuth | ForEach-Object { $_.sAMAccountName }) -AffectedCount $noPreAuth.Count
    }

    return $results
}
