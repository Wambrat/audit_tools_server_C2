# -----------------------------------------------------------------------------
# Fonction : New-ADCheckResult
# Description : Fabrique un objet de resultat normalise pour les controles
#               Active Directory. Toutes les fonctions d'audit AD renvoient
#               des objets construits par cette fabrique afin que Start-Audit.ps1
#               puisse les traiter de maniere uniforme.
# -----------------------------------------------------------------------------

function New-ADCheckResult {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$CheckId,
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Title,
        [Parameter(Mandatory = $true)][string]$Category,

        # Reference au referentiel ANSSI (points de controle AD / DAT-NT-017)
        [string]$AnssiRef = "",

        [ValidateSet("Critique", "Majeur", "Mineur", "Info")]
        [string]$Severity = "Majeur",

        # UNKNOWN = controle non evaluable (droits, RSAT, connectivite)
        [ValidateSet("PASS", "FAIL", "WARNING", "UNKNOWN")]
        [string]$Status = "UNKNOWN",

        [string]$Comment = "",
        [string]$Recommendation = "",

        # Chaine ou tableau : liste des objets en ecart
        $Details = $null,

        [int]$AffectedCount = 0,
        [bool]$Automatable = $false,

        # Nombre maximum d'elements listes dans Details (evite un rapport illisible)
        [int]$MaxDetails = 20
    )

    $detailText = ""

    if ($null -ne $Details) {
        if ($Details -is [string]) {
            $detailText = $Details
        }
        else {
            $items = @($Details | Where-Object { $null -ne $_ -and "$_" -ne "" })
            if ($items.Count -gt 0) {
                $shown = $items | Select-Object -First $MaxDetails
                $detailText = ($shown -join " ; ")
                if ($items.Count -gt $MaxDetails) {
                    $detailText += " ... (+$($items.Count - $MaxDetails) autres)"
                }
            }
        }
    }

    return [PSCustomObject]@{
        CheckId        = $CheckId
        Name           = $Name
        Title          = $Title
        Category       = $Category
        AnssiRef       = $AnssiRef
        Severity       = $Severity
        Status         = $Status
        Comment        = $Comment
        Recommendation = $Recommendation
        Details        = $detailText
        AffectedCount  = $AffectedCount
        Automatable    = $Automatable
    }
}
