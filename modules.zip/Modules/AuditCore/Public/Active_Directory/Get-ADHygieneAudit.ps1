# -----------------------------------------------------------------------------
# Fonction : Get-ADHygieneAudit
# Description : Controles ANSSI AD-46 a AD-50 - hygiene de l'annuaire,
#               relations d'approbation, comptes herites et journalisation des
#               controleurs de domaine.
# -----------------------------------------------------------------------------

function Get-ADHygieneAudit {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$Context,

        [int]$InactivityDays = 90
    )

    $results = @()
    $srv = $Context.Server
    $cat = "Hygiene de l'annuaire et journalisation"

    $inactiveLimit = (Get-Date).AddDays(-$InactivityDays)
    $inactiveFileTime = $inactiveLimit.ToFileTime()

    # =========================================================================
    # AD-46 : Comptes utilisateurs inactifs toujours actives
    # =========================================================================
    try {
        $totalUsers = @(Get-ADUser -LDAPFilter "(&(objectCategory=person)(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))" `
                        -Server $srv -ErrorAction Stop).Count

        $inactiveUsers = @(Get-ADUser -LDAPFilter "(&(objectCategory=person)(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2))(|(lastLogonTimestamp<=$inactiveFileTime)(!(lastLogonTimestamp=*))))" `
                            -Server $srv -Properties sAMAccountName, lastLogonTimestamp, whenCreated -ErrorAction Stop)

        # Les comptes crees recemment n'ont pas encore de lastLogonTimestamp : on les ignore
        $inactiveUsers = @($inactiveUsers | Where-Object { $_.whenCreated -lt $inactiveLimit })

        $ratio = 0
        if ($totalUsers -gt 0) { $ratio = [Math]::Round(($inactiveUsers.Count / $totalUsers) * 100, 1) }

        $status = "PASS"
        if ($ratio -ge 25) { $status = "FAIL" }
        elseif ($inactiveUsers.Count -gt 0) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-46" -Name "InactiveUserAccounts" `
            -Title "Comptes utilisateurs inactifs toujours actives" `
            -Category $cat -AnssiRef "ANSSI vuln3_inactive_accounts" -Severity "Majeur" -Status $status `
            -Comment "$($inactiveUsers.Count) compte(s) actif(s) sur $totalUsers ($ratio %) sans connexion depuis plus de $InactivityDays jours." `
            -Recommendation "Mettre en place un processus de revue periodique : desactiver les comptes inutilises depuis $InactivityDays jours, puis les supprimer apres une periode de retention definie. Ces comptes sont des cibles privilegiees car leur compromission passe inapercue." `
            -Details @($inactiveUsers | ForEach-Object { $_.sAMAccountName }) -AffectedCount $inactiveUsers.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-46" -Name "InactiveUserAccounts" `
            -Title "Comptes utilisateurs inactifs toujours actives" `
            -Category $cat -AnssiRef "ANSSI vuln3_inactive_accounts" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Recherche des comptes inactifs impossible : $($_.Exception.Message)" `
            -Recommendation "Verifier les droits de lecture de l'annuaire."
    }

    # =========================================================================
    # AD-47 : Comptes machine inactifs
    # =========================================================================
    try {
        $totalComputers = @(Get-ADComputer -LDAPFilter "(!(userAccountControl:1.2.840.113556.1.4.803:=2))" -Server $srv -ErrorAction Stop).Count

        $inactiveComputers = @(Get-ADComputer -LDAPFilter "(&(!(userAccountControl:1.2.840.113556.1.4.803:=2))(|(lastLogonTimestamp<=$inactiveFileTime)(!(lastLogonTimestamp=*))))" `
                                -Server $srv -Properties sAMAccountName, lastLogonTimestamp, whenCreated, OperatingSystem -ErrorAction Stop)
        $inactiveComputers = @($inactiveComputers | Where-Object { $_.whenCreated -lt $inactiveLimit })

        $status = "PASS"
        if ($totalComputers -gt 0 -and (($inactiveComputers.Count / $totalComputers) * 100) -ge 25) { $status = "FAIL" }
        elseif ($inactiveComputers.Count -gt 0) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-47" -Name "InactiveComputerAccounts" `
            -Title "Comptes machine inactifs toujours actives" `
            -Category $cat -AnssiRef "ANSSI vuln3_inactive_computers" -Severity "Mineur" -Status $status `
            -Comment "$($inactiveComputers.Count) compte(s) machine sur $totalComputers sans authentification depuis plus de $InactivityDays jours." `
            -Recommendation "Desactiver puis supprimer les comptes machine obsoletes : leur secret n'est plus renouvele et reste utilisable pour s'authentifier dans le domaine (silver ticket, RBCD)." `
            -Details @($inactiveComputers | ForEach-Object { "$($_.sAMAccountName) [$($_.OperatingSystem)]" }) `
            -AffectedCount $inactiveComputers.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-47" -Name "InactiveComputerAccounts" `
            -Title "Comptes machine inactifs toujours actives" `
            -Category $cat -AnssiRef "ANSSI vuln3_inactive_computers" -Severity "Mineur" -Status "UNKNOWN" `
            -Comment "Recherche des comptes machine inactifs impossible : $($_.Exception.Message)" `
            -Recommendation "Verifier les droits de lecture de l'annuaire."
    }

    # =========================================================================
    # AD-48 : Securite des relations d'approbation
    # =========================================================================
    try {
        $trusts = @(Get-ADTrust -Filter * -Server $srv -ErrorAction Stop)

        $issues = @()
        foreach ($t in $trusts) {
            # Approbation externe ou de foret sans filtrage de SID
            if ($t.SIDFilteringQuarantined -eq $false -and "$($t.TrustType)" -match "External|Uplevel" -and $t.IntraForest -eq $false) {
                $issues += "$($t.Name) : filtrage des SID desactive"
            }
            if ($t.TGTDelegation -eq $true) {
                $issues += "$($t.Name) : delegation des TGT autorisee"
            }
            if ($t.SelectiveAuthentication -eq $false -and $t.IntraForest -eq $false) {
                $issues += "$($t.Name) : authentification selective non activee"
            }
        }

        $status = if ($trusts.Count -eq 0) { "PASS" } elseif ($issues.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-48" -Name "TrustRelationshipsSecurity" `
            -Title "Securite des relations d'approbation" `
            -Category $cat -AnssiRef "ANSSI vuln1_trust_sid_filtering" -Severity "Critique" -Status $status `
            -Comment "$($trusts.Count) approbation(s) declaree(s), $($issues.Count) ecart(s) de configuration." `
            -Recommendation "Activer le filtrage des SID et l'authentification selective sur toutes les approbations sortantes hors foret, et interdire la delegation des TGT : sans filtrage, un administrateur du domaine approuve peut injecter un SID privilegie et prendre le controle du domaine." `
            -Details ($issues + @($trusts | ForEach-Object { "$($_.Name) [$($_.TrustType)/$($_.Direction)]" })) `
            -AffectedCount $issues.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-48" -Name "TrustRelationshipsSecurity" `
            -Title "Securite des relations d'approbation" `
            -Category $cat -AnssiRef "ANSSI vuln1_trust_sid_filtering" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Enumeration des approbations impossible : $($_.Exception.Message)" `
            -Recommendation "Controler manuellement les approbations avec netdom trust /quarantine."
    }

    # =========================================================================
    # AD-49 : Comptes et groupes herites (Invite, Acces compatible pre-Windows 2000)
    # =========================================================================
    $legacyIssues = @()
    $legacyEvaluated = $false

    try {
        $guest = Get-ADUser -Identity "$($Context.DomainSID)-501" -Server $srv -Properties Enabled -ErrorAction Stop
        $legacyEvaluated = $true
        if ($guest.Enabled) { $legacyIssues += "Compte Invite du domaine active ($($guest.SamAccountName))" }
    }
    catch { }

    try {
        # S-1-5-32-554 : Acces compatible pre-Windows 2000
        $preWin2k = Get-ADGroup -Identity "S-1-5-32-554" -Server $srv -Properties Members -ErrorAction Stop
        $legacyEvaluated = $true

        foreach ($memberDn in @($preWin2k.Members)) {
            # Tout le monde (S-1-1-0), Connexion anonyme (S-1-5-7), Utilisateurs authentifies (S-1-5-11)
            if ($memberDn -match "CN=S-1-1-0|CN=S-1-5-7|CN=S-1-5-11") {
                $legacyIssues += "Acces compatible pre-Windows 2000 contient $memberDn"
            }
        }
    }
    catch { }

    $status = if (-not $legacyEvaluated) { "UNKNOWN" } elseif ($legacyIssues.Count -eq 0) { "PASS" } else { "FAIL" }

    $results += New-ADCheckResult -CheckId "AD-49" -Name "LegacyAccountsAndGroups" `
        -Title "Compte Invite et groupe Acces compatible pre-Windows 2000" `
        -Category $cat -AnssiRef "ANSSI vuln1_pre_windows_2000 / vuln2_guest_enabled" -Severity "Critique" -Status $status `
        -Comment "$($legacyIssues.Count) configuration(s) heritee(s) a risque detectee(s)." `
        -Recommendation "Desactiver le compte Invite du domaine et retirer Tout le monde, Connexion anonyme et Utilisateurs authentifies du groupe Acces compatible pre-Windows 2000 : leur presence autorise l'enumeration anonyme de l'annuaire." `
        -Details $legacyIssues -AffectedCount $legacyIssues.Count

    # =========================================================================
    # AD-50 : Strategie d'audit avancee sur les controleurs de domaine
    # =========================================================================
    # Sous-categories d'audit indispensables sur un DC (GUID stables, non localises)
    $requiredSubcategories = @{
        "0CCE923F" = "Validation des informations d'identification"
        "0CCE9242" = "Service d'authentification Kerberos"
        "0CCE9240" = "Operations de ticket de service Kerberos"
        "0CCE9235" = "Gestion des comptes d'utilisateur"
        "0CCE9236" = "Gestion des comptes d'ordinateur"
        "0CCE9237" = "Gestion des groupes de securite"
        "0CCE923B" = "Acces au service d'annuaire"
        "0CCE923C" = "Modifications du service d'annuaire"
        "0CCE9215" = "Ouverture de session"
        "0CCE921B" = "Ouverture de session speciale"
        "0CCE922B" = "Creation de processus"
        "0CCE922F" = "Modification de la strategie d'audit"
    }

    $auditCsvPath = Join-Path -Path $Context.SysvolPath `
                        -ChildPath "Policies\{6AC1786C-016F-11D2-945F-00C04FB984F9}\MACHINE\Microsoft\Windows NT\Audit\audit.csv"

    if (Test-Path -LiteralPath $auditCsvPath) {
        try {
            $auditRows = @(Import-Csv -LiteralPath $auditCsvPath -ErrorAction Stop)
            $configured = @{}

            foreach ($row in $auditRows) {
                $guid = "$($row.'Subcategory GUID')"
                $setting = "$($row.'Inclusion Setting')"
                foreach ($key in $requiredSubcategories.Keys) {
                    if ($guid -match $key -and $setting -and $setting -notmatch "No Auditing|Aucun audit") {
                        $configured[$key] = $true
                    }
                }
            }

            $missing = @()
            foreach ($key in $requiredSubcategories.Keys) {
                if (-not $configured.ContainsKey($key)) { $missing += $requiredSubcategories[$key] }
            }

            $status = if ($missing.Count -eq 0) { "PASS" } elseif ($missing.Count -le 3) { "WARNING" } else { "FAIL" }

            $results += New-ADCheckResult -CheckId "AD-50" -Name "DomainControllerAuditPolicy" `
                -Title "Strategie d'audit avancee des controleurs de domaine" `
                -Category $cat -AnssiRef "ANSSI vuln2_audit_policy / Guide journalisation" -Severity "Majeur" -Status $status `
                -Comment "$($missing.Count) sous-categorie(s) d'audit indispensable(s) non configuree(s) sur $($requiredSubcategories.Count)." `
                -Recommendation "Activer la strategie d'audit avancee sur les controleurs de domaine (authentification Kerberos, gestion des comptes et des groupes, acces et modifications de l'annuaire, creation de processus) et centraliser ces journaux : sans eux, aucune attaque sur l'annuaire n'est detectable ni analysable a posteriori." `
                -Details $missing -AffectedCount $missing.Count
        }
        catch {
            $results += New-ADCheckResult -CheckId "AD-50" -Name "DomainControllerAuditPolicy" `
                -Title "Strategie d'audit avancee des controleurs de domaine" `
                -Category $cat -AnssiRef "ANSSI vuln2_audit_policy" -Severity "Majeur" -Status "UNKNOWN" `
                -Comment "Lecture de audit.csv impossible : $($_.Exception.Message)" `
                -Recommendation "Verifier manuellement la strategie d'audit avancee appliquee aux controleurs de domaine (auditpol /get /category:*)."
        }
    }
    elseif (-not (Test-Path -LiteralPath $Context.SysvolPath)) {
        # SYSVOL injoignable : on ne peut rien conclure sur la strategie d'audit
        $results += New-ADCheckResult -CheckId "AD-50" -Name "DomainControllerAuditPolicy" `
            -Title "Strategie d'audit avancee des controleurs de domaine" `
            -Category $cat -AnssiRef "ANSSI vuln2_audit_policy" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Partage SYSVOL inaccessible ($($Context.SysvolPath)) : strategie d'audit non evaluable." `
            -Recommendation "Verifier l'acces au partage SYSVOL depuis la machine d'audit, ou controler la strategie d'audit avancee directement sur les controleurs de domaine (auditpol /get /category:*)."
    }
    else {
        $results += New-ADCheckResult -CheckId "AD-50" -Name "DomainControllerAuditPolicy" `
            -Title "Strategie d'audit avancee des controleurs de domaine" `
            -Category $cat -AnssiRef "ANSSI vuln2_audit_policy" -Severity "Majeur" -Status "WARNING" `
            -Comment "Aucune strategie d'audit avancee dans la Default Domain Controllers Policy ; elle peut etre definie dans une autre GPO liee a l'OU des controleurs de domaine (verification manuelle requise)." `
            -Recommendation "Definir la strategie d'audit avancee dans la GPO des controleurs de domaine (ou dans une GPO dediee qui leur est liee) et verifier avec auditpol /get /category:* sur chaque DC." `
            -Details "Fichier attendu absent : $auditCsvPath"
    }

    return $results
}
