# -----------------------------------------------------------------------------
# Fonction : Test-ADPrivilegedTrustee
# Description : Indique si un beneficiaire d'ACE (IdentityReference) fait partie
#               des principaux d'administration attendus. Sert a distinguer les
#               ACE legitimes des delegations ajoutees sur les objets sensibles.
#               Renvoie $true pour un principal attendu, $false sinon.
# Attention : Utilisateurs authentifies, Utilisateurs du domaine, Tout le monde
#             et Acces compatible pre-Windows 2000 sont volontairement absents
#             de la liste : leur presence sur une ACE en ecriture constitue
#             precisement un ecart a signaler.
# -----------------------------------------------------------------------------

function Test-ADPrivilegedTrustee {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Trustee
    )

    $expected = @(
        'NT AUTHORITY\\SYSTEM', 'AUTORITE NT\\Sys',
        'NT AUTHORITY\\SELF', 'AUTORITE NT\\AUTO',
        'BUILTIN\\Administrators', 'BUILTIN\\Administrateurs',
        'CREATOR OWNER', 'CREATEUR PROPRIETAIRE',
        '\\Domain Admins$', '\\Admins du domaine$',
        '\\Enterprise Admins$', '\\Administrateurs de l.+entreprise$',
        '\\Schema Admins$', '\\Administrateurs du schema$',
        '\\Enterprise Domain Controllers', '\\Controleurs de domaine d.+entreprise',
        '\\Domain Controllers$', '\\Controleurs de domaine$',
        '\\Key Admins$', '\\Enterprise Key Admins$', '\\Cloneable Domain Controllers$',
        '\\Administrator$', '\\Administrateur$',
        '^S-1-5-32-544$', '^S-1-5-9$', '^S-1-5-18$'
    )

    foreach ($pattern in $expected) {
        if ($Trustee -match $pattern) { return $true }
    }

    return $false
}
