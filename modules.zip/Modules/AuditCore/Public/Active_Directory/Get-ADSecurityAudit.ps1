# -----------------------------------------------------------------------------
# Fonction : Get-ADSecurityAudit
# Description : Orchestrateur de l'audit Active Directory. Prepare le contexte
#               puis execute les 50 points de controle ANSSI repartis en six
#               familles :
#                 AD-01 a AD-12 : comptes et groupes a privileges (Tier 0)
#                 AD-13 a AD-22 : mots de passe et attributs de comptes
#                 AD-23 a AD-30 : Kerberos, delegations et comptes de service
#                 AD-31 a AD-38 : controleurs de domaine et socle de l'annuaire
#                 AD-39 a AD-45 : permissions, GPO et SYSVOL
#                 AD-46 a AD-50 : hygiene, approbations et journalisation
#
#               Si l'annuaire n'est pas interrogeable (machine hors domaine,
#               RSAT absent, droits insuffisants), la fonction renvoie
#               Available = $false et un unique controle AD-00 explicitant la
#               raison, plutot qu'une serie de faux positifs.
#
# Referentiel : ANSSI - "Points de controle Active Directory" et guide
#               DAT-NT-017 "Recommandations de securite relatives a Active Directory".
# -----------------------------------------------------------------------------

function Get-ADSecurityAudit {
    [CmdletBinding()]
    param(
        # Controleur de domaine a interroger (par defaut : emulateur PDC)
        [string]$Server,

        # Contexte deja construit par Get-ADAuditContext (evite un second appel)
        $Context,

        # Nombre de jours sans authentification au-dela duquel un compte est inactif
        [int]$InactivityDays = 90,

        # Familles de controles a executer (par defaut : toutes)
        [ValidateSet("Privileges", "Comptes", "Kerberos", "Infrastructure", "Permissions", "Hygiene")]
        [string[]]$Include = @("Privileges", "Comptes", "Kerberos", "Infrastructure", "Permissions", "Hygiene")
    )

    if (-not $Context) {
        if ($Server) { $Context = Get-ADAuditContext -Server $Server }
        else { $Context = Get-ADAuditContext }
    }

    $checks = @()

    # --- Prerequis non reunis : on s'arrete proprement ------------------------
    if (-not $Context.Available) {
        $status = "UNKNOWN"
        $recommendation = "Executer l'audit Active Directory depuis une machine du domaine disposant du module RSAT-AD-PowerShell et d'un compte autorise a lire l'annuaire."

        if ($Context.IsDomainJoined -and -not $Context.ModuleAvailable) {
            $status = "FAIL"
            $recommendation = "Installer le module RSAT-AD-PowerShell (Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0) pour executer les 50 points de controle Active Directory."
        }

        $checks += New-ADCheckResult -CheckId "AD-00" -Name "ActiveDirectoryAuditPrerequisites" `
            -Title "Prerequis de l'audit Active Directory" `
            -Category "Prerequis" -AnssiRef "-" -Severity "Info" -Status $status `
            -Comment $Context.Reason `
            -Recommendation $recommendation `
            -Details "IsDomainJoined=$($Context.IsDomainJoined) ; ModuleActiveDirectory=$($Context.ModuleAvailable) ; IsDomainController=$($Context.IsDomainController) ; Elevation=$($Context.IsElevated)"

        return [PSCustomObject]@{
            Available = $false
            Reason    = $Context.Reason
            Context   = $Context
            Checks    = $checks
            Summary   = [PSCustomObject]@{
                Total = $checks.Count; Pass = 0; Fail = ($checks | Where-Object { $_.Status -eq "FAIL" }).Count
                Warning = 0; Unknown = ($checks | Where-Object { $_.Status -eq "UNKNOWN" }).Count; CriticalFail = 0
            }
        }
    }

    # --- Execution des familles de controles ---------------------------------
    $families = @(
        @{ Key = "Privileges";     Label = "Comptes a privileges (AD-01 a AD-12)";        Command = { Get-ADPrivilegedAccountsAudit -Context $Context -InactivityDays $InactivityDays } },
        @{ Key = "Comptes";        Label = "Mots de passe et comptes (AD-13 a AD-22)";    Command = { Get-ADAccountSecurityAudit -Context $Context } },
        @{ Key = "Kerberos";       Label = "Kerberos et delegations (AD-23 a AD-30)";     Command = { Get-ADKerberosAudit -Context $Context } },
        @{ Key = "Infrastructure"; Label = "Controleurs de domaine (AD-31 a AD-38)";      Command = { Get-ADInfrastructureAudit -Context $Context } },
        @{ Key = "Permissions";    Label = "Permissions, GPO et SYSVOL (AD-39 a AD-45)";  Command = { Get-ADPermissionsAudit -Context $Context } },
        @{ Key = "Hygiene";        Label = "Hygiene et journalisation (AD-46 a AD-50)";   Command = { Get-ADHygieneAudit -Context $Context -InactivityDays $InactivityDays } }
    )

    foreach ($family in $families) {
        if ($Include -notcontains $family.Key) { continue }

        Write-Verbose "Audit AD : $($family.Label)"
        try {
            $checks += @(& $family.Command)
        }
        catch {
            # Une famille en echec ne doit pas interrompre l'audit complet
            Write-Warning "Famille '$($family.Label)' en echec : $($_.Exception.Message)"
            $checks += New-ADCheckResult -CheckId "AD-ERR-$($family.Key)" -Name "$($family.Key)AuditError" `
                -Title "Erreur d'execution : $($family.Label)" `
                -Category "Prerequis" -AnssiRef "-" -Severity "Info" -Status "UNKNOWN" `
                -Comment "L'execution de cette famille de controles a echoue : $($_.Exception.Message)" `
                -Recommendation "Relancer l'audit avec un compte disposant des droits de lecture necessaires sur l'annuaire et sur SYSVOL."
        }
    }

    # --- Completion des controles non produits -------------------------------
    # Une requete en echec peut empecher une famille d'emettre un resultat : on
    # complete depuis le catalogue pour que le rapport presente les 50 lignes.
    $emitted = @($checks | ForEach-Object { $_.CheckId })

    foreach ($entry in (Get-ADCheckCatalog)) {
        if ($Include.Count -lt 6) { break }   # audit partiel demande : pas de completion
        if ($emitted -contains $entry.CheckId) { continue }

        $checks += New-ADCheckResult -CheckId $entry.CheckId -Name $entry.Name `
            -Title $entry.Title -Category $entry.Category -AnssiRef $entry.AnssiRef `
            -Severity $entry.Severity -Status "UNKNOWN" `
            -Comment "Controle non evalue : les donnees necessaires n'ont pas pu etre collectees dans l'annuaire." `
            -Recommendation "Relancer l'audit avec un compte disposant des droits de lecture requis, ou verifier manuellement ce point de controle."
    }

    $checks = @($checks | Sort-Object CheckId)

    $summary = [PSCustomObject]@{
        Total        = $checks.Count
        Pass         = @($checks | Where-Object { $_.Status -eq "PASS" }).Count
        Fail         = @($checks | Where-Object { $_.Status -eq "FAIL" }).Count
        Warning      = @($checks | Where-Object { $_.Status -eq "WARNING" }).Count
        Unknown      = @($checks | Where-Object { $_.Status -eq "UNKNOWN" }).Count
        CriticalFail = @($checks | Where-Object { $_.Status -eq "FAIL" -and $_.Severity -eq "Critique" }).Count
    }

    return [PSCustomObject]@{
        Available = $true
        Reason    = ""
        Context   = $Context
        Checks    = $checks
        Summary   = $summary
    }
}
