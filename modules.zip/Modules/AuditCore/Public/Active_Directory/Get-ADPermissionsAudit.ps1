# -----------------------------------------------------------------------------
# Fonction : Get-ADPermissionsAudit
# Description : Controles ANSSI AD-39 a AD-45 - permissions de l'annuaire,
#               strategies de groupe et partage SYSVOL.
# Referentiel : ANSSI "Points de controle Active Directory" (permissions sur le
#               domaine, droits de replication, GPO, mots de passe GPP).
# -----------------------------------------------------------------------------

function Get-ADPermissionsAudit {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$Context,

        # Nombre maximum de GPO dont les ACL sont analysees (limite le temps d'audit)
        [int]$MaxGpoToInspect = 200
    )

    $results = @()
    $srv = $Context.Server
    $cat = "Permissions, GPO et SYSVOL"

    # Droits etendus utilises pour la replication de l'annuaire (DCSync)
    $GUID_GET_CHANGES     = "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2"
    $GUID_GET_CHANGES_ALL = "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2"

    $dangerousRightsPattern = 'GenericAll|WriteDacl|WriteOwner|GenericWrite|WriteProperty|CreateChild|Self'

    # =========================================================================
    # AD-39 : Permissions non standard sur la racine du domaine
    # =========================================================================
    try {
        $rootAcl = Get-Acl -Path "AD:\$($Context.DomainDN)" -ErrorAction Stop

        $suspicious = @()
        foreach ($ace in $rootAcl.Access) {
            if ($ace.AccessControlType -ne 'Allow') { continue }
            $trustee = "$($ace.IdentityReference)"
            if (Test-ADPrivilegedTrustee -Trustee $trustee) { continue }
            if ("$($ace.ActiveDirectoryRights)" -match $dangerousRightsPattern) {
                $suspicious += "$trustee -> $($ace.ActiveDirectoryRights)"
            }
        }

        $status = if ($suspicious.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-39" -Name "DomainRootPermissions" `
            -Title "Permissions en ecriture non standard sur la racine du domaine" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_domain" -Severity "Critique" -Status $status `
            -Comment "$($suspicious.Count) ACE en ecriture accordee(s) a des principaux non administratifs sur l'objet domaine." `
            -Recommendation "Retirer toute delegation en ecriture accordee sur la racine du domaine a des groupes non Tier 0 : ces droits sont herites par l'ensemble de l'annuaire et equivalent a une prise de controle du domaine." `
            -Details $suspicious -AffectedCount $suspicious.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-39" -Name "DomainRootPermissions" `
            -Title "Permissions en ecriture non standard sur la racine du domaine" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_domain" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Lecture des ACL de la racine du domaine impossible : $($_.Exception.Message)" `
            -Recommendation "Executer l'audit avec un compte autorise a lire les descripteurs de securite de l'annuaire."
    }

    # =========================================================================
    # AD-40 : Droits de replication de l'annuaire (DCSync)
    # =========================================================================
    try {
        $rootAcl = Get-Acl -Path "AD:\$($Context.DomainDN)" -ErrorAction Stop

        $dcSync = @()
        foreach ($ace in $rootAcl.Access) {
            if ($ace.AccessControlType -ne 'Allow') { continue }
            if ("$($ace.ActiveDirectoryRights)" -notmatch 'ExtendedRight') { continue }

            $objType = "$($ace.ObjectType)"
            if ($objType -ne $GUID_GET_CHANGES -and $objType -ne $GUID_GET_CHANGES_ALL) { continue }

            $trustee = "$($ace.IdentityReference)"
            if (Test-ADPrivilegedTrustee -Trustee $trustee) { continue }

            $rightName = if ($objType -eq $GUID_GET_CHANGES_ALL) { "DS-Replication-Get-Changes-All" } else { "DS-Replication-Get-Changes" }
            $dcSync += "$trustee -> $rightName"
        }

        $status = if ($dcSync.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-40" -Name "DcSyncPermissions" `
            -Title "Droits de replication de l'annuaire (DCSync) accordes hors Tier 0" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_dcsync" -Severity "Critique" -Status $status `
            -Comment "$($dcSync.Count) principal(aux) non administratif(s) disposent de droits de replication sur le domaine." `
            -Recommendation "Retirer les droits DS-Replication-Get-Changes et DS-Replication-Get-Changes-All des principaux non Tier 0 : leur combinaison permet d'extraire l'ensemble des empreintes de mots de passe du domaine, dont celle du compte krbtgt." `
            -Details $dcSync -AffectedCount $dcSync.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-40" -Name "DcSyncPermissions" `
            -Title "Droits de replication de l'annuaire (DCSync) accordes hors Tier 0" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_dcsync" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Analyse des droits de replication impossible : $($_.Exception.Message)" `
            -Recommendation "Controler manuellement les droits etendus de replication sur l'objet domaine."
    }

    # =========================================================================
    # AD-41 : Strategies de groupe modifiables par des principaux non administratifs
    # =========================================================================
    try {
        $gpos = @(Get-ADObject -LDAPFilter "(objectClass=groupPolicyContainer)" `
                    -SearchBase "CN=Policies,CN=System,$($Context.DomainDN)" `
                    -Server $srv -Properties displayName, distinguishedName -ErrorAction Stop |
                    Select-Object -First $MaxGpoToInspect)

        $writable = @()
        foreach ($gpo in $gpos) {
            try { $acl = Get-Acl -Path "AD:\$($gpo.DistinguishedName)" -ErrorAction Stop } catch { continue }

            foreach ($ace in $acl.Access) {
                if ($ace.AccessControlType -ne 'Allow') { continue }
                $trustee = "$($ace.IdentityReference)"
                if (Test-ADPrivilegedTrustee -Trustee $trustee) { continue }
                if ("$($ace.ActiveDirectoryRights)" -match 'GenericAll|GenericWrite|WriteDacl|WriteOwner|WriteProperty') {
                    $name = if ($gpo.displayName) { $gpo.displayName } else { $gpo.Name }
                    $writable += "$name : $trustee -> $($ace.ActiveDirectoryRights)"
                }
            }
        }

        $status = if ($writable.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-41" -Name "GpoWritePermissions" `
            -Title "GPO modifiables par des principaux non administratifs" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_gpo" -Severity "Critique" -Status $status `
            -Comment "$($writable.Count) delegation(s) en ecriture detectee(s) sur $($gpos.Count) GPO analysees." `
            -Recommendation "Reserver la modification des GPO aux administrateurs du domaine, en particulier pour celles liees a l'OU des controleurs de domaine : pouvoir editer une GPO revient a executer du code sur toutes les machines qu'elle cible." `
            -Details $writable -AffectedCount $writable.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-41" -Name "GpoWritePermissions" `
            -Title "GPO modifiables par des principaux non administratifs" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_gpo" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Analyse des ACL des GPO impossible : $($_.Exception.Message)" `
            -Recommendation "Verifier les droits de lecture sur le conteneur CN=Policies,CN=System."
    }

    # =========================================================================
    # AD-42 : Mots de passe stockes dans les preferences de strategie de groupe
    # =========================================================================
    $policiesPath = Join-Path -Path $Context.SysvolPath -ChildPath "Policies"
    if (Test-Path -LiteralPath $policiesPath) {
        try {
            $gppFiles = @(Get-ChildItem -LiteralPath $policiesPath -Recurse -Include "*.xml" -File -ErrorAction SilentlyContinue |
                            Select-String -Pattern "cpassword" -List -ErrorAction SilentlyContinue)

            $status = if ($gppFiles.Count -eq 0) { "PASS" } else { "FAIL" }

            $results += New-ADCheckResult -CheckId "AD-42" -Name "GppPasswordsInSysvol" `
                -Title "Mots de passe en clair dans les preferences de strategie de groupe (cpassword)" `
                -Category $cat -AnssiRef "ANSSI vuln1_gpp_password" -Severity "Critique" -Status $status `
                -Comment "$($gppFiles.Count) fichier(s) de preferences GPO contiennent un attribut cpassword." `
                -Recommendation "Supprimer ces fichiers de SYSVOL et renouveler immediatement les mots de passe concernes : la cle AES utilisee par les preferences de strategie de groupe est publiee par Microsoft, ces secrets sont donc lisibles par tout utilisateur du domaine." `
                -Details @($gppFiles | ForEach-Object { $_.Path }) -AffectedCount $gppFiles.Count
        }
        catch {
            $results += New-ADCheckResult -CheckId "AD-42" -Name "GppPasswordsInSysvol" `
                -Title "Mots de passe en clair dans les preferences de strategie de groupe (cpassword)" `
                -Category $cat -AnssiRef "ANSSI vuln1_gpp_password" -Severity "Critique" -Status "UNKNOWN" `
                -Comment "Parcours de SYSVOL impossible : $($_.Exception.Message)" `
                -Recommendation "Rechercher manuellement la chaine cpassword dans les fichiers XML de SYSVOL."
        }
    }
    else {
        $results += New-ADCheckResult -CheckId "AD-42" -Name "GppPasswordsInSysvol" `
            -Title "Mots de passe en clair dans les preferences de strategie de groupe (cpassword)" `
            -Category $cat -AnssiRef "ANSSI vuln1_gpp_password" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Partage SYSVOL inaccessible ($policiesPath)." `
            -Recommendation "Verifier l'acces au partage SYSVOL depuis la machine d'audit."
    }

    # =========================================================================
    # AD-43 : Quota de creation de comptes machine par les utilisateurs
    # =========================================================================
    try {
        $domainObj = Get-ADObject -Identity $Context.DomainDN -Server $srv `
                        -Properties "ms-DS-MachineAccountQuota" -ErrorAction Stop
        $quota = $domainObj."ms-DS-MachineAccountQuota"
        if ($null -eq $quota) { $quota = 10 }
        $quota = [int]$quota

        $status = if ($quota -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-43" -Name "MachineAccountQuota" `
            -Title "Quota de creation de comptes machine par les utilisateurs standard" `
            -Category $cat -AnssiRef "ANSSI vuln2_machine_account_quota" -Severity "Majeur" -Status $status `
            -Comment "ms-DS-MachineAccountQuota = $quota." `
            -Recommendation "Positionner ms-DS-MachineAccountQuota a 0 et deleguer la jonction au domaine a une equipe identifiee : la valeur par defaut (10) permet a tout utilisateur de creer des comptes machine, prerequis de nombreuses attaques (RBCD, noPac, certificats)." `
            -Details "ms-DS-MachineAccountQuota=$quota"
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-43" -Name "MachineAccountQuota" `
            -Title "Quota de creation de comptes machine par les utilisateurs standard" `
            -Category $cat -AnssiRef "ANSSI vuln2_machine_account_quota" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Lecture de ms-DS-MachineAccountQuota impossible : $($_.Exception.Message)" `
            -Recommendation "Controler manuellement l'attribut ms-DS-MachineAccountQuota sur l'objet domaine."
    }

    # =========================================================================
    # AD-44 : Proprietaires non administratifs sur les objets privilegies
    # =========================================================================
    try {
        $privilegedGroupSids = @(
            "$($Context.DomainSID)-512",     # Admins du domaine
            "$($Context.RootDomainSID)-519", # Administrateurs de l'entreprise
            "$($Context.RootDomainSID)-518", # Administrateurs du schema
            "S-1-5-32-544",                  # Administrateurs (builtin)
            "S-1-5-32-548", "S-1-5-32-549", "S-1-5-32-550", "S-1-5-32-551"
        )

        $badOwners = @()
        $inspected = 0

        foreach ($sid in $privilegedGroupSids) {
            try { $grp = Get-ADGroup -Identity $sid -Server $srv -ErrorAction Stop } catch { continue }
            try { $acl = Get-Acl -Path "AD:\$($grp.DistinguishedName)" -ErrorAction Stop } catch { continue }

            $inspected++
            if (-not (Test-ADPrivilegedTrustee -Trustee "$($acl.Owner)")) {
                $badOwners += "$($grp.Name) : proprietaire $($acl.Owner)"
            }
        }

        $status = if ($inspected -eq 0) { "UNKNOWN" } elseif ($badOwners.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-44" -Name "PrivilegedObjectOwners" `
            -Title "Proprietaires non administratifs sur les groupes privilegies" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_priv_objects" -Severity "Critique" -Status $status `
            -Comment "$($badOwners.Count) groupe(s) privilegie(s) sur $inspected appartiennent a un proprietaire non Tier 0." `
            -Recommendation "Redefinir le proprietaire des groupes d'administration sur Admins du domaine ou Administrateurs : le proprietaire d'un objet peut toujours en reecrire les ACL, quelles que soient les permissions en place." `
            -Details $badOwners -AffectedCount $badOwners.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-44" -Name "PrivilegedObjectOwners" `
            -Title "Proprietaires non administratifs sur les groupes privilegies" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_priv_objects" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Analyse des proprietaires impossible : $($_.Exception.Message)" `
            -Recommendation "Controler manuellement les proprietaires des groupes d'administration."
    }

    # =========================================================================
    # AD-45 : Droits en ecriture des utilisateurs standard sur SYSVOL et NETLOGON
    # =========================================================================
    $sharesToCheck = @(
        @{ Label = "SYSVOL\Policies"; Path = $policiesPath },
        @{ Label = "NETLOGON";        Path = Join-Path -Path $Context.SysvolPath -ChildPath "Scripts" }
    )

    $writableShares = @()
    $sharesInspected = 0
    $unsafeGroups = 'Everyone|Tout le monde|Authenticated Users|Utilisateurs authentifies|Domain Users|Utilisateurs du domaine|ANONYMOUS'

    foreach ($share in $sharesToCheck) {
        if (-not (Test-Path -LiteralPath $share.Path)) { continue }
        try {
            $acl = Get-Acl -Path $share.Path -ErrorAction Stop
            $sharesInspected++

            foreach ($ace in $acl.Access) {
                if ($ace.AccessControlType -ne 'Allow') { continue }
                if ("$($ace.IdentityReference)" -notmatch $unsafeGroups) { continue }
                if ("$($ace.FileSystemRights)" -match 'FullControl|Modify|Write|TakeOwnership|ChangePermissions') {
                    $writableShares += "$($share.Label) : $($ace.IdentityReference) -> $($ace.FileSystemRights)"
                }
            }
        }
        catch { }
    }

    $status = if ($sharesInspected -eq 0) { "UNKNOWN" } elseif ($writableShares.Count -eq 0) { "PASS" } else { "FAIL" }

    $results += New-ADCheckResult -CheckId "AD-45" -Name "SysvolNetlogonWriteAccess" `
        -Title "Droits en ecriture des utilisateurs standard sur SYSVOL et NETLOGON" `
        -Category $cat -AnssiRef "ANSSI vuln1_sysvol_permissions" -Severity "Critique" -Status $status `
        -Comment "$($writableShares.Count) ACE en ecriture accordee(s) a des groupes larges sur $sharesInspected emplacement(s) analyse(s)." `
        -Recommendation "Restreindre SYSVOL et NETLOGON a un acces en lecture pour les utilisateurs et machines du domaine : un droit d'ecriture y permet de modifier les scripts de connexion et les GPO, donc d'executer du code sur tout le parc." `
        -Details $writableShares -AffectedCount $writableShares.Count

    return $results
}
