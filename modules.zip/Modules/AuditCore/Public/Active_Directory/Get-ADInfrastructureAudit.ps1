# -----------------------------------------------------------------------------
# Fonction : Get-ADInfrastructureAudit
# Description : Controles ANSSI AD-31 a AD-38 - controleurs de domaine et
#               socle de l'annuaire (niveaux fonctionnels, systemes obsoletes,
#               durcissement LDAP/SMB, sauvegarde, replication, dsHeuristics,
#               spouleur d'impression).
# Remarque : plusieurs controles interrogent le registre distant des DC. Si le
#            service Remote Registry est arrete ou si le compte d'audit n'est
#            pas administrateur des DC, le controle renvoie UNKNOWN plutot
#            qu'un faux positif.
# -----------------------------------------------------------------------------

function Get-ADInfrastructureAudit {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$Context,

        [int]$BackupMaxAgeDays = 7
    )

    $results = @()
    $srv = $Context.Server
    $cat = "Infrastructure et controleurs de domaine"

    # --- Helper : lecture d'une valeur de registre locale ou distante --------
    function Get-DCRegistryValue {
        param([string]$Computer, [string]$Key, [string]$Name)

        try {
            if ($Computer -eq $env:COMPUTERNAME -or $Computer -like "$env:COMPUTERNAME.*") {
                $item = Get-ItemProperty -Path "HKLM:\$Key" -Name $Name -ErrorAction Stop
                return $item.$Name
            }

            $base = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, $Computer)
            $sub = $base.OpenSubKey($Key)
            if ($null -eq $sub) { return $null }
            return $sub.GetValue($Name)
        }
        catch { return $null }
    }

    # --- Liste des controleurs de domaine ------------------------------------
    $dcs = @()
    try { $dcs = @(Get-ADDomainController -Filter * -Server $srv -ErrorAction Stop) } catch { }

    # =========================================================================
    # AD-31 : Niveaux fonctionnels du domaine et de la foret
    # =========================================================================
    $modeRank = @{
        "Windows2000Domain" = 0; "Windows2000Forest" = 0
        "Windows2003InterimDomain" = 1; "Windows2003InterimForest" = 1
        "Windows2003Domain" = 2; "Windows2003Forest" = 2
        "Windows2008Domain" = 3; "Windows2008Forest" = 3
        "Windows2008R2Domain" = 4; "Windows2008R2Forest" = 4
        "Windows2012Domain" = 5; "Windows2012Forest" = 5
        "Windows2012R2Domain" = 6; "Windows2012R2Forest" = 6
        "Windows2016Domain" = 7; "Windows2016Forest" = 7
        "Windows2025Domain" = 10; "Windows2025Forest" = 10
    }

    $domainRank = if ($modeRank.ContainsKey($Context.DomainMode)) { $modeRank[$Context.DomainMode] } else { -1 }
    $forestRank = if ($modeRank.ContainsKey($Context.ForestMode)) { $modeRank[$Context.ForestMode] } else { -1 }

    $status = "UNKNOWN"
    if ($domainRank -ge 0 -and $forestRank -ge 0) {
        $minRank = [Math]::Min($domainRank, $forestRank)
        if ($minRank -ge 7) { $status = "PASS" }
        elseif ($minRank -ge 6) { $status = "WARNING" }
        else { $status = "FAIL" }
    }

    $results += New-ADCheckResult -CheckId "AD-31" -Name "FunctionalLevels" `
        -Title "Niveaux fonctionnels du domaine et de la foret" `
        -Category $cat -AnssiRef "ANSSI vuln2_functional_level" -Severity "Majeur" -Status $status `
        -Comment "Niveau fonctionnel du domaine : $($Context.DomainMode) ; de la foret : $($Context.ForestMode)." `
        -Recommendation "Relever les niveaux fonctionnels a Windows Server 2016 au minimum : les mecanismes de protection modernes (Utilisateurs proteges, Authentication Policy Silos, durcissement Kerberos) ne sont disponibles qu'a partir de 2012 R2 / 2016." `
        -Details "DomainMode=$($Context.DomainMode) ; ForestMode=$($Context.ForestMode)"

    # =========================================================================
    # AD-32 : Systemes d'exploitation obsoletes sur les controleurs de domaine
    # =========================================================================
    if ($dcs.Count -gt 0) {
        $obsolete = @($dcs | Where-Object { "$($_.OperatingSystem)" -match "2000|2003|2008|2012" })
        $status = if ($obsolete.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-32" -Name "ObsoleteDomainControllerOS" `
            -Title "Controleurs de domaine sous systeme obsolete" `
            -Category $cat -AnssiRef "ANSSI vuln1_dc_obsolete_os" -Severity "Critique" -Status $status `
            -Comment "$($obsolete.Count) controleur(s) de domaine sur $($dcs.Count) fonctionnent sous un systeme non supporte." `
            -Recommendation "Migrer les controleurs de domaine vers une version supportee de Windows Server (2019 ou ulterieure) : un DC non supporte ne recoit plus de correctifs de securite et compromet l'ensemble de la foret." `
            -Details @($dcs | ForEach-Object { "$($_.HostName) : $($_.OperatingSystem)" }) -AffectedCount $obsolete.Count
    }
    else {
        $results += New-ADCheckResult -CheckId "AD-32" -Name "ObsoleteDomainControllerOS" `
            -Title "Controleurs de domaine sous systeme obsolete" `
            -Category $cat -AnssiRef "ANSSI vuln1_dc_obsolete_os" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Enumeration des controleurs de domaine impossible." `
            -Recommendation "Verifier la connectivite avec l'annuaire."
    }

    # =========================================================================
    # AD-33 : Signature LDAP et liaison de canal exigees sur les DC
    # =========================================================================
    if ($dcs.Count -gt 0) {
        $nonCompliant = @()
        $unreachable = @()

        foreach ($dc in $dcs) {
            $integrity = Get-DCRegistryValue -Computer $dc.HostName -Key "SYSTEM\CurrentControlSet\Services\NTDS\Parameters" -Name "LDAPServerIntegrity"
            $binding   = Get-DCRegistryValue -Computer $dc.HostName -Key "SYSTEM\CurrentControlSet\Services\NTDS\Parameters" -Name "LdapEnforceChannelBinding"

            if ($null -eq $integrity -and $null -eq $binding) { $unreachable += $dc.HostName; continue }

            $issues = @()
            if ([int]$integrity -ne 2) { $issues += "LDAPServerIntegrity=$integrity" }
            if ([int]$binding -ne 2) { $issues += "LdapEnforceChannelBinding=$binding" }
            if ($issues.Count -gt 0) { $nonCompliant += "$($dc.HostName) : $($issues -join ', ')" }
        }

        $status = "PASS"
        if ($nonCompliant.Count -gt 0) { $status = "FAIL" }
        elseif ($unreachable.Count -eq $dcs.Count) { $status = "UNKNOWN" }
        elseif ($unreachable.Count -gt 0) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-33" -Name "LdapSigningAndChannelBinding" `
            -Title "Signature LDAP et liaison de canal exigees sur les controleurs de domaine" `
            -Category $cat -AnssiRef "ANSSI vuln1_ldap_signing" -Severity "Critique" -Status $status `
            -Comment "$($nonCompliant.Count) DC non conforme(s), $($unreachable.Count) DC non interrogeable(s) sur $($dcs.Count)." `
            -Recommendation "Positionner LDAPServerIntegrity=2 (signature LDAP obligatoire) et LdapEnforceChannelBinding=2 sur tous les controleurs de domaine, apres verification de la compatibilite des clients : sans cela, les authentifications LDAP sont relayables." `
            -Details ($nonCompliant + @($unreachable | ForEach-Object { "$_ : registre distant inaccessible" })) `
            -AffectedCount $nonCompliant.Count
    }

    # =========================================================================
    # AD-34 : Signature SMB obligatoire sur les controleurs de domaine
    # =========================================================================
    if ($dcs.Count -gt 0) {
        $nonCompliant = @()
        $unreachable = @()

        foreach ($dc in $dcs) {
            $requireSig = Get-DCRegistryValue -Computer $dc.HostName -Key "SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "RequireSecuritySignature"
            if ($null -eq $requireSig) { $unreachable += $dc.HostName; continue }
            if ([int]$requireSig -ne 1) { $nonCompliant += "$($dc.HostName) : RequireSecuritySignature=$requireSig" }
        }

        $status = "PASS"
        if ($nonCompliant.Count -gt 0) { $status = "FAIL" }
        elseif ($unreachable.Count -eq $dcs.Count) { $status = "UNKNOWN" }
        elseif ($unreachable.Count -gt 0) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-34" -Name "DomainControllerSmbSigning" `
            -Title "Signature SMB obligatoire sur les controleurs de domaine" `
            -Category $cat -AnssiRef "ANSSI vuln1_smb_signing_dc" -Severity "Critique" -Status $status `
            -Comment "$($nonCompliant.Count) DC sans signature SMB obligatoire, $($unreachable.Count) non interrogeable(s) sur $($dcs.Count)." `
            -Recommendation "Exiger la signature SMB cote serveur sur tous les controleurs de domaine (parametre 'Serveur reseau Microsoft : signer numeriquement les communications - toujours') afin de bloquer le relais SMB vers SYSVOL et NETLOGON." `
            -Details ($nonCompliant + @($unreachable | ForEach-Object { "$_ : registre distant inaccessible" })) `
            -AffectedCount $nonCompliant.Count
    }

    # =========================================================================
    # AD-35 : Anciennete de la derniere sauvegarde de l'annuaire
    # =========================================================================
    try {
        $backupOutput = & repadmin /showbackup $Context.DomainName 2>$null
        $dates = @()
        foreach ($line in @($backupOutput)) {
            if ("$line" -match '(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})') {
                try { $dates += [datetime]::Parse($Matches[1]) } catch { }
            }
        }

        if ($dates.Count -gt 0) {
            $last = ($dates | Sort-Object -Descending)[0]
            $ageDays = [int]((Get-Date) - $last).TotalDays
            $status = if ($ageDays -le $BackupMaxAgeDays) { "PASS" } elseif ($ageDays -le (2 * $BackupMaxAgeDays)) { "WARNING" } else { "FAIL" }

            $results += New-ADCheckResult -CheckId "AD-35" -Name "DirectoryBackupAge" `
                -Title "Anciennete de la derniere sauvegarde de l'annuaire" `
                -Category $cat -AnssiRef "ANSSI vuln2_backup_age" -Severity "Majeur" -Status $status `
                -Comment "Derniere sauvegarde AD detectee le $($last.ToString('yyyy-MM-dd')) ($ageDays jours)." `
                -Recommendation "Sauvegarder l'etat du systeme d'au moins deux controleurs de domaine au moins une fois par semaine, conserver les sauvegardes hors ligne et tester regulierement la procedure de restauration de foret." `
                -Details "Derniere sauvegarde : $last"
        }
        else {
            $results += New-ADCheckResult -CheckId "AD-35" -Name "DirectoryBackupAge" `
                -Title "Anciennete de la derniere sauvegarde de l'annuaire" `
                -Category $cat -AnssiRef "ANSSI vuln2_backup_age" -Severity "Majeur" -Status "UNKNOWN" `
                -Comment "Aucune date de sauvegarde exploitable retournee par repadmin /showbackup." `
                -Recommendation "Verifier manuellement l'existence et la fraicheur des sauvegardes d'etat systeme des controleurs de domaine."
        }
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-35" -Name "DirectoryBackupAge" `
            -Title "Anciennete de la derniere sauvegarde de l'annuaire" `
            -Category $cat -AnssiRef "ANSSI vuln2_backup_age" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Commande repadmin indisponible : $($_.Exception.Message)" `
            -Recommendation "Installer les outils d'administration AD (repadmin) ou controler manuellement les sauvegardes."
    }

    # =========================================================================
    # AD-36 : Sante de la replication entre controleurs de domaine
    # =========================================================================
    try {
        $meta = @(Get-ADReplicationPartnerMetadata -Target $Context.DomainName -Scope Domain -ErrorAction Stop)
        $failures = @($meta | Where-Object { $_.LastReplicationResult -ne 0 })

        $status = if ($meta.Count -eq 0) { "UNKNOWN" } elseif ($failures.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-36" -Name "ReplicationHealth" `
            -Title "Sante de la replication Active Directory" `
            -Category $cat -AnssiRef "ANSSI vuln2_replication_failure" -Severity "Majeur" -Status $status `
            -Comment "$($failures.Count) lien(s) de replication en erreur sur $($meta.Count) analyse(s)." `
            -Recommendation "Corriger les erreurs de replication : un DC desynchronise ne recoit ni les desactivations de comptes ni les modifications de GPO, ce qui laisse subsister des acces revoques." `
            -Details @($failures | ForEach-Object { "$($_.Server) <- $($_.Partner) : code $($_.LastReplicationResult)" }) `
            -AffectedCount $failures.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-36" -Name "ReplicationHealth" `
            -Title "Sante de la replication Active Directory" `
            -Category $cat -AnssiRef "ANSSI vuln2_replication_failure" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Analyse de la replication impossible : $($_.Exception.Message)" `
            -Recommendation "Executer repadmin /replsummary depuis un controleur de domaine."
    }

    # =========================================================================
    # AD-37 : dsHeuristics - operations LDAP anonymes
    # =========================================================================
    try {
        $dsService = Get-ADObject -Identity "CN=Directory Service,CN=Windows NT,CN=Services,$($Context.ConfigurationDN)" `
                        -Server $srv -Properties dSHeuristics -ErrorAction Stop
        $heuristics = "$($dsService.dSHeuristics)"

        $anonymousAllowed = ($heuristics.Length -ge 7 -and $heuristics[6] -eq '2')
        $status = if ($anonymousAllowed) { "FAIL" } else { "PASS" }

        $results += New-ADCheckResult -CheckId "AD-37" -Name "DsHeuristicsAnonymousLdap" `
            -Title "Operations LDAP anonymes autorisees (dsHeuristics)" `
            -Category $cat -AnssiRef "ANSSI vuln1_dsheuristics_bad" -Severity "Critique" -Status $status `
            -Comment "dSHeuristics = '$heuristics' ; operations LDAP anonymes : $(if ($anonymousAllowed) { 'autorisees' } else { 'refusees' })." `
            -Recommendation "Le 7e caractere de dSHeuristics ne doit pas valoir 2 : cette valeur autorise les requetes LDAP anonymes et permet a un attaquant non authentifie d'enumerer l'annuaire." `
            -Details "dSHeuristics='$heuristics'"
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-37" -Name "DsHeuristicsAnonymousLdap" `
            -Title "Operations LDAP anonymes autorisees (dsHeuristics)" `
            -Category $cat -AnssiRef "ANSSI vuln1_dsheuristics_bad" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Lecture de l'objet Directory Service impossible : $($_.Exception.Message)" `
            -Recommendation "Controler manuellement l'attribut dSHeuristics dans la partition de configuration."
    }

    # =========================================================================
    # AD-38 : Service de spouleur d'impression actif sur les DC
    # =========================================================================
    if ($dcs.Count -gt 0) {
        $spoolerOn = @()
        $unreachable = @()

        foreach ($dc in $dcs) {
            $start = Get-DCRegistryValue -Computer $dc.HostName -Key "SYSTEM\CurrentControlSet\Services\Spooler" -Name "Start"
            if ($null -eq $start) { $unreachable += $dc.HostName; continue }
            # 2 = demarrage automatique, 3 = manuel, 4 = desactive
            if ([int]$start -le 3) { $spoolerOn += "$($dc.HostName) : Start=$start" }
        }

        $status = "PASS"
        if ($spoolerOn.Count -gt 0) { $status = "FAIL" }
        elseif ($unreachable.Count -eq $dcs.Count) { $status = "UNKNOWN" }
        elseif ($unreachable.Count -gt 0) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-38" -Name "PrintSpoolerOnDomainControllers" `
            -Title "Service de spouleur d'impression actif sur les controleurs de domaine" `
            -Category $cat -AnssiRef "ANSSI vuln2_spooler_dc" -Severity "Majeur" -Status $status `
            -Comment "$($spoolerOn.Count) DC avec un spouleur non desactive, $($unreachable.Count) non interrogeable(s) sur $($dcs.Count)." `
            -Recommendation "Desactiver le service Spouleur d'impression sur les controleurs de domaine : il expose PrinterBug/PrintNightmare et permet de forcer une authentification du compte machine du DC vers un serveur controle par l'attaquant." `
            -Details ($spoolerOn + @($unreachable | ForEach-Object { "$_ : registre distant inaccessible" })) `
            -AffectedCount $spoolerOn.Count
    }

    return $results
}
