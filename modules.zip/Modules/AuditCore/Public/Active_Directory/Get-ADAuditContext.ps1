# -----------------------------------------------------------------------------
# Fonction : Get-ADAuditContext
# Description : Prepare le contexte necessaire aux controles Active Directory.
#               1. Verifie l'appartenance au domaine.
#               2. Verifie la presence du module ActiveDirectory (RSAT).
#               3. Recupere domaine, foret, SID, DN, DC contacte et SYSVOL.
#               Si Available = $false, aucun controle AD ne peut etre execute :
#               la raison est portee par la propriete Reason.
# -----------------------------------------------------------------------------

function Get-ADAuditContext {
    [CmdletBinding()]
    param(
        # Controleur de domaine a interroger (par defaut : detection automatique)
        [string]$Server
    )

    $ctx = [PSCustomObject]@{
        Available          = $false
        Reason             = ""
        IsDomainJoined     = $false
        IsDomainController = $false
        ModuleAvailable    = $false
        Server             = ""
        DomainName         = ""
        NetBiosName        = ""
        DomainDN           = ""
        DomainSID          = ""
        DomainMode         = ""
        ForestName         = ""
        ForestMode         = ""
        RootDomainDN       = ""
        RootDomainSID      = ""
        ConfigurationDN    = ""
        SysvolPath         = ""
        IsElevated         = $false
    }

    # --- 1. Appartenance au domaine et role de la machine ---
    try {
        $cs = Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop
        $ctx.IsDomainJoined = [bool]$cs.PartOfDomain
        $ctx.IsDomainController = ($cs.DomainRole -eq 4 -or $cs.DomainRole -eq 5)
    }
    catch {
        $ctx.Reason = "Impossible de determiner le role de la machine (WMI indisponible)."
        return $ctx
    }

    try {
        $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = [System.Security.Principal.WindowsPrincipal]$identity
        $ctx.IsElevated = $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch { }

    if (-not $ctx.IsDomainJoined) {
        $ctx.Reason = "Machine non jointe a un domaine : audit Active Directory non applicable."
        return $ctx
    }

    # --- 2. Disponibilite du module ActiveDirectory ---
    if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
        $ctx.Reason = "Module PowerShell ActiveDirectory (RSAT) absent : installer RSAT-AD-PowerShell pour executer les controles AD."
        return $ctx
    }

    try {
        Import-Module ActiveDirectory -ErrorAction Stop -WarningAction SilentlyContinue
        $ctx.ModuleAvailable = $true
    }
    catch {
        $ctx.Reason = "Chargement du module ActiveDirectory impossible : $($_.Exception.Message)"
        return $ctx
    }

    # --- 3. Collecte des informations de domaine et de foret ---
    try {
        if ($Server) {
            $domain = Get-ADDomain -Server $Server -ErrorAction Stop
        }
        else {
            $domain = Get-ADDomain -Current LocalComputer -ErrorAction Stop
        }

        $ctx.Server          = if ($Server) { $Server } else { $domain.PDCEmulator }
        $ctx.DomainName      = $domain.DNSRoot
        $ctx.NetBiosName     = $domain.NetBIOSName
        $ctx.DomainDN        = $domain.DistinguishedName
        $ctx.DomainSID       = $domain.DomainSID.Value
        $ctx.DomainMode      = "$($domain.DomainMode)"
        $ctx.SysvolPath      = "\\$($domain.DNSRoot)\SYSVOL\$($domain.DNSRoot)"

        $forest = Get-ADForest -Server $ctx.Server -ErrorAction Stop
        $ctx.ForestName      = $forest.Name
        $ctx.ForestMode      = "$($forest.ForestMode)"

        $rootDomain = Get-ADDomain -Identity $forest.RootDomain -Server $ctx.Server -ErrorAction Stop
        $ctx.RootDomainDN    = $rootDomain.DistinguishedName
        $ctx.RootDomainSID   = $rootDomain.DomainSID.Value

        $rootDse = Get-ADRootDSE -Server $ctx.Server -ErrorAction Stop
        $ctx.ConfigurationDN = $rootDse.configurationNamingContext

        $ctx.Available = $true
    }
    catch {
        $ctx.Reason = "Interrogation de l'annuaire impossible : $($_.Exception.Message)"
    }

    return $ctx
}
