# -----------------------------------------------------------------------------
# Fonction : Get-ADGpoSecurityTemplate
# Description : Lit le modele de securite (GptTmpl.inf) d'une GPO depuis SYSVOL
#               et le renvoie sous forme de table de hachage
#               [Section] -> @{ Cle = Valeur }.
#               Utilise pour auditer des parametres qui ne sont pas exposes par
#               les cmdlets AD : politique Kerberos, valeurs de registre LSA,
#               strategie d'audit, signature SMB.
# GUID connus : {31B2F340-016D-11D2-945F-00C04FB984F9} = Default Domain Policy
#               {6AC1786C-016F-11D2-945F-00C04FB984F9} = Default Domain Controllers Policy
# -----------------------------------------------------------------------------

function Get-ADGpoSecurityTemplate {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$Context,

        [Parameter(Mandatory = $true)]
        [string]$GpoGuid
    )

    $path = Join-Path -Path $Context.SysvolPath -ChildPath "Policies\$GpoGuid\MACHINE\Microsoft\Windows NT\SecEdit\GptTmpl.inf"

    if (-not (Test-Path -LiteralPath $path)) { return $null }

    try {
        $content = Get-Content -LiteralPath $path -ErrorAction Stop
    }
    catch {
        Write-Verbose "Lecture de $path impossible : $($_.Exception.Message)"
        return $null
    }

    $template = @{}
    $section = "Global"

    foreach ($rawLine in $content) {
        $line = $rawLine.Trim()
        if (-not $line -or $line.StartsWith(";")) { continue }

        if ($line -match '^\[(.+)\]$') {
            $section = $Matches[1]
            if (-not $template.ContainsKey($section)) { $template[$section] = @{} }
            continue
        }

        $idx = $line.IndexOf('=')
        if ($idx -lt 1) { continue }

        $key = $line.Substring(0, $idx).Trim()
        $value = $line.Substring($idx + 1).Trim()

        if (-not $template.ContainsKey($section)) { $template[$section] = @{} }
        $template[$section][$key] = $value
    }

    return $template
}
