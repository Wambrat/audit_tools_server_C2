# -----------------------------------------------------------------------------
# Fonction : ConvertTo-ADFilterValue
# Description : Echappe une valeur (typiquement un DistinguishedName) avant son
#               insertion dans un filtre LDAP, conformement a la RFC 4515.
#               Evite qu'un DN contenant une parenthese ou une virgule echappee
#               ne casse la requete.
# -----------------------------------------------------------------------------

function ConvertTo-ADFilterValue {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Value
    )

    $escaped = $Value
    $escaped = $escaped -replace '\\', '\5c'
    $escaped = $escaped -replace '\(', '\28'
    $escaped = $escaped -replace '\)', '\29'
    $escaped = $escaped -replace '\*', '\2a'
    $escaped = $escaped -replace "`0", '\00'

    return $escaped
}
