# -----------------------------------------------------------------------------
# Fonction : Get-ADCheckCatalog
# Description : Catalogue de reference des 50 points de controle Active Directory
#               retenus d'apres le referentiel ANSSI. Il sert de source de verite
#               a Get-ADSecurityAudit : tout controle qu'une famille n'a pas pu
#               produire (requete en echec, prerequis absent) est complete a
#               partir de ce catalogue avec le statut UNKNOWN, afin que le
#               rapport presente toujours les 50 lignes attendues.
#
#               Toute nouvelle regle doit etre ajoutee ici ET dans la fonction
#               d'audit correspondante, avec le meme CheckId.
# -----------------------------------------------------------------------------

function Get-ADCheckCatalog {
    [CmdletBinding()]
    param()

    $catalog = @(
        # --- Comptes a privileges (Tier 0) -----------------------------------
        @{ CheckId = 'AD-01'; Name = 'DomainAdminsMembership'; Title = 'Nombre et nature des membres du groupe Admins du domaine'; Category = 'Comptes a privileges'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_privileged_members' }
        @{ CheckId = 'AD-02'; Name = 'EnterpriseAdminsMembership'; Title = 'Groupe Administrateurs de l''entreprise vide hors operations'; Category = 'Comptes a privileges'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_privileged_members' }
        @{ CheckId = 'AD-03'; Name = 'SchemaAdminsMembership'; Title = 'Groupe Administrateurs du schema vide hors operations'; Category = 'Comptes a privileges'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_privileged_members' }
        @{ CheckId = 'AD-04'; Name = 'BuiltinAdministratorsMembership'; Title = 'Composition du groupe Administrateurs integre du domaine'; Category = 'Comptes a privileges'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_privileged_members / DAT-NT-017 R1' }
        @{ CheckId = 'AD-05'; Name = 'BuiltinOperatorGroups'; Title = 'Groupes d''operateurs integres (Account/Server/Print/Backup Operators, DnsAdmins) vides'; Category = 'Comptes a privileges'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_privileged_members / vuln2_dnsadmins' }
        @{ CheckId = 'AD-06'; Name = 'ProtectedUsersGroup'; Title = 'Comptes privilegies membres du groupe Utilisateurs proteges'; Category = 'Comptes a privileges'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln3_admin_accounts_not_protected' }
        @{ CheckId = 'AD-07'; Name = 'SensitiveAndNotDelegated'; Title = 'Comptes privilegies marques comme sensibles et non delegables'; Category = 'Comptes a privileges'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_admin_accounts_not_sensitive' }
        @{ CheckId = 'AD-08'; Name = 'PrivilegedPasswordAge'; Title = 'Renouvellement des mots de passe des comptes privilegies'; Category = 'Comptes a privileges'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_admin_password_age / DAT-NT-017' }
        @{ CheckId = 'AD-09'; Name = 'PrivilegedInactiveAccounts'; Title = 'Comptes privilegies inactifs encore actifs dans l''annuaire'; Category = 'Comptes a privileges'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_admin_accounts_inactive' }
        @{ CheckId = 'AD-10'; Name = 'AdminSDHolderAcl'; Title = 'Permissions non standard sur le conteneur AdminSDHolder'; Category = 'Comptes a privileges'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_permissions_adminsdholder' }
        @{ CheckId = 'AD-11'; Name = 'OrphanAdminCountAccounts'; Title = 'Comptes avec adminCount=1 hors des groupes privilegies'; Category = 'Comptes a privileges'; Severity = 'Mineur'; AnssiRef = 'ANSSI vuln3_admincount_orphan' }
        @{ CheckId = 'AD-12'; Name = 'PrivilegedAccountsWithSpn'; Title = 'Comptes privilegies exposant un SPN (kerberoasting sur Tier 0)'; Category = 'Comptes a privileges'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_priv_spn' }

        # --- Authentification et mots de passe --------------------------------
        @{ CheckId = 'AD-13'; Name = 'DomainPasswordMinLength'; Title = 'Longueur minimale des mots de passe de la politique de domaine'; Category = 'Authentification et mots de passe'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_password_length' }
        @{ CheckId = 'AD-14'; Name = 'DomainPasswordComplexity'; Title = 'Exigence de complexite des mots de passe'; Category = 'Authentification et mots de passe'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_password_complexity' }
        @{ CheckId = 'AD-15'; Name = 'DomainAccountLockoutPolicy'; Title = 'Politique de verrouillage des comptes du domaine'; Category = 'Authentification et mots de passe'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_account_lockout' }
        @{ CheckId = 'AD-16'; Name = 'FineGrainedPasswordPolicies'; Title = 'Strategies de mot de passe affinees pour les comptes a privileges'; Category = 'Authentification et mots de passe'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln3_no_pso / DAT-NT-017' }
        @{ CheckId = 'AD-17'; Name = 'PasswordNotRequiredAccounts'; Title = 'Comptes actifs dispenses de mot de passe (PASSWD_NOTREQD)'; Category = 'Authentification et mots de passe'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_no_password_required' }
        @{ CheckId = 'AD-18'; Name = 'PasswordNeverExpiresAccounts'; Title = 'Comptes actifs dont le mot de passe n''expire jamais'; Category = 'Authentification et mots de passe'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_password_never_expires' }
        @{ CheckId = 'AD-19'; Name = 'ReversiblePasswordEncryption'; Title = 'Stockage des mots de passe avec chiffrement reversible'; Category = 'Authentification et mots de passe'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_reversible_password' }
        @{ CheckId = 'AD-20'; Name = 'NoLMHashStorage'; Title = 'Interdiction du stockage des empreintes LM'; Category = 'Authentification et mots de passe'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_lm_hash' }
        @{ CheckId = 'AD-21'; Name = 'DesOnlyAccounts'; Title = 'Comptes limites au chiffrement Kerberos DES'; Category = 'Authentification et mots de passe'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_des_enabled' }
        @{ CheckId = 'AD-22'; Name = 'KerberosPreAuthDisabled'; Title = 'Comptes sans pre-authentification Kerberos (AS-REP roasting)'; Category = 'Authentification et mots de passe'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln2_kerberos_preauth' }

        # --- Kerberos, delegations et comptes de service -----------------------
        @{ CheckId = 'AD-23'; Name = 'KrbtgtPasswordAge'; Title = 'Renouvellement du mot de passe du compte krbtgt'; Category = 'Kerberos et delegations'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_krbtgt' }
        @{ CheckId = 'AD-24'; Name = 'UnconstrainedDelegation'; Title = 'Delegation Kerberos non contrainte hors controleurs de domaine'; Category = 'Kerberos et delegations'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_delegation_t4d' }
        @{ CheckId = 'AD-25'; Name = 'ConstrainedDelegationProtocolTransition'; Title = 'Delegation contrainte avec transition de protocole (S4U2Self)'; Category = 'Kerberos et delegations'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_delegation_t2a4d' }
        @{ CheckId = 'AD-26'; Name = 'ResourceBasedConstrainedDelegation'; Title = 'Delegation contrainte basee sur les ressources (RBCD)'; Category = 'Kerberos et delegations'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_delegation_rbcd' }
        @{ CheckId = 'AD-27'; Name = 'KerberosEncryptionTypes'; Title = 'Algorithmes de chiffrement Kerberos des comptes de service'; Category = 'Kerberos et delegations'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_kerberos_rc4' }
        @{ CheckId = 'AD-28'; Name = 'KerberosTicketLifetime'; Title = 'Duree de vie et validation des tickets Kerberos'; Category = 'Kerberos et delegations'; Severity = 'Mineur'; AnssiRef = 'ANSSI vuln2_kerberos_ticket_lifetime' }
        @{ CheckId = 'AD-29'; Name = 'KerberoastableServiceAccounts'; Title = 'Comptes de service kerberoastables a mot de passe ancien'; Category = 'Kerberos et delegations'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_spn_password_age' }
        @{ CheckId = 'AD-30'; Name = 'GroupManagedServiceAccounts'; Title = 'Utilisation de comptes de service geres (gMSA)'; Category = 'Kerberos et delegations'; Severity = 'Mineur'; AnssiRef = 'ANSSI vuln3_no_gmsa / DAT-NT-017' }

        # --- Infrastructure et controleurs de domaine --------------------------
        @{ CheckId = 'AD-31'; Name = 'FunctionalLevels'; Title = 'Niveaux fonctionnels du domaine et de la foret'; Category = 'Infrastructure et controleurs de domaine'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_functional_level' }
        @{ CheckId = 'AD-32'; Name = 'ObsoleteDomainControllerOS'; Title = 'Controleurs de domaine sous systeme obsolete'; Category = 'Infrastructure et controleurs de domaine'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_dc_obsolete_os' }
        @{ CheckId = 'AD-33'; Name = 'LdapSigningAndChannelBinding'; Title = 'Signature LDAP et liaison de canal exigees sur les controleurs de domaine'; Category = 'Infrastructure et controleurs de domaine'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_ldap_signing' }
        @{ CheckId = 'AD-34'; Name = 'DomainControllerSmbSigning'; Title = 'Signature SMB obligatoire sur les controleurs de domaine'; Category = 'Infrastructure et controleurs de domaine'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_smb_signing_dc' }
        @{ CheckId = 'AD-35'; Name = 'DirectoryBackupAge'; Title = 'Anciennete de la derniere sauvegarde de l''annuaire'; Category = 'Infrastructure et controleurs de domaine'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_backup_age' }
        @{ CheckId = 'AD-36'; Name = 'ReplicationHealth'; Title = 'Sante de la replication Active Directory'; Category = 'Infrastructure et controleurs de domaine'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_replication_failure' }
        @{ CheckId = 'AD-37'; Name = 'DsHeuristicsAnonymousLdap'; Title = 'Operations LDAP anonymes autorisees (dsHeuristics)'; Category = 'Infrastructure et controleurs de domaine'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_dsheuristics_bad' }
        @{ CheckId = 'AD-38'; Name = 'PrintSpoolerOnDomainControllers'; Title = 'Service de spouleur d''impression actif sur les controleurs de domaine'; Category = 'Infrastructure et controleurs de domaine'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_spooler_dc' }

        # --- Permissions, GPO et SYSVOL ----------------------------------------
        @{ CheckId = 'AD-39'; Name = 'DomainRootPermissions'; Title = 'Permissions en ecriture non standard sur la racine du domaine'; Category = 'Permissions, GPO et SYSVOL'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_permissions_domain' }
        @{ CheckId = 'AD-40'; Name = 'DcSyncPermissions'; Title = 'Droits de replication de l''annuaire (DCSync) accordes hors Tier 0'; Category = 'Permissions, GPO et SYSVOL'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_permissions_dcsync' }
        @{ CheckId = 'AD-41'; Name = 'GpoWritePermissions'; Title = 'GPO modifiables par des principaux non administratifs'; Category = 'Permissions, GPO et SYSVOL'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_permissions_gpo' }
        @{ CheckId = 'AD-42'; Name = 'GppPasswordsInSysvol'; Title = 'Mots de passe en clair dans les preferences de strategie de groupe (cpassword)'; Category = 'Permissions, GPO et SYSVOL'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_gpp_password' }
        @{ CheckId = 'AD-43'; Name = 'MachineAccountQuota'; Title = 'Quota de creation de comptes machine par les utilisateurs standard'; Category = 'Permissions, GPO et SYSVOL'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_machine_account_quota' }
        @{ CheckId = 'AD-44'; Name = 'PrivilegedObjectOwners'; Title = 'Proprietaires non administratifs sur les groupes privilegies'; Category = 'Permissions, GPO et SYSVOL'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_permissions_priv_objects' }
        @{ CheckId = 'AD-45'; Name = 'SysvolNetlogonWriteAccess'; Title = 'Droits en ecriture des utilisateurs standard sur SYSVOL et NETLOGON'; Category = 'Permissions, GPO et SYSVOL'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_sysvol_permissions' }

        # --- Hygiene de l'annuaire et journalisation ---------------------------
        @{ CheckId = 'AD-46'; Name = 'InactiveUserAccounts'; Title = 'Comptes utilisateurs inactifs toujours actives'; Category = 'Hygiene de l''annuaire et journalisation'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln3_inactive_accounts' }
        @{ CheckId = 'AD-47'; Name = 'InactiveComputerAccounts'; Title = 'Comptes machine inactifs toujours actives'; Category = 'Hygiene de l''annuaire et journalisation'; Severity = 'Mineur'; AnssiRef = 'ANSSI vuln3_inactive_computers' }
        @{ CheckId = 'AD-48'; Name = 'TrustRelationshipsSecurity'; Title = 'Securite des relations d''approbation'; Category = 'Hygiene de l''annuaire et journalisation'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_trust_sid_filtering' }
        @{ CheckId = 'AD-49'; Name = 'LegacyAccountsAndGroups'; Title = 'Compte Invite et groupe Acces compatible pre-Windows 2000'; Category = 'Hygiene de l''annuaire et journalisation'; Severity = 'Critique'; AnssiRef = 'ANSSI vuln1_pre_windows_2000 / vuln2_guest_enabled' }
        @{ CheckId = 'AD-50'; Name = 'DomainControllerAuditPolicy'; Title = 'Strategie d''audit avancee des controleurs de domaine'; Category = 'Hygiene de l''annuaire et journalisation'; Severity = 'Majeur'; AnssiRef = 'ANSSI vuln2_audit_policy / Guide journalisation' }
    )

    return @($catalog | ForEach-Object { [PSCustomObject]$_ })
}
