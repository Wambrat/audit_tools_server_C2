# -----------------------------------------------------------------------------
# Fonction : Get-ADKerberosAudit
# Description : Controles ANSSI AD-23 a AD-30 - Kerberos, delegations et
#               comptes de service.
# Referentiel : ANSSI "Points de controle Active Directory" (delegations,
#               krbtgt, algorithmes de chiffrement Kerberos).
# -----------------------------------------------------------------------------

function Get-ADKerberosAudit {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$Context,

        [int]$KrbtgtMaxAgeDays = 365,
        [int]$ServiceAccountPasswordMaxAgeDays = 365
    )

    $results = @()
    $srv = $Context.Server
    $cat = "Kerberos et delegations"

    # DN du conteneur des controleurs de domaine (exclusion legitime pour la delegation)
    $dcOuDn = "OU=Domain Controllers,$($Context.DomainDN)"

    function Test-IsDomainController {
        param($Object)
        if ($Object.DistinguishedName -like "*$dcOuDn") { return $true }
        if ($Object.primaryGroupID -eq 516 -or $Object.primaryGroupID -eq 521) { return $true }
        return $false
    }

    # =========================================================================
    # AD-23 : Anciennete du mot de passe du compte krbtgt
    # =========================================================================
    try {
        $krbtgt = Get-ADUser -Identity "$($Context.DomainSID)-502" -Server $srv `
                    -Properties PasswordLastSet, sAMAccountName -ErrorAction Stop
        $ageDays = $null
        if ($krbtgt.PasswordLastSet) { $ageDays = [int]((Get-Date) - $krbtgt.PasswordLastSet).TotalDays }

        $status = "UNKNOWN"
        $comment = "Date de dernier changement du mot de passe krbtgt inconnue."
        if ($null -ne $ageDays) {
            $comment = "Mot de passe du compte krbtgt change il y a $ageDays jours ($($krbtgt.PasswordLastSet.ToString('yyyy-MM-dd')))."
            if ($ageDays -gt $KrbtgtMaxAgeDays) { $status = "FAIL" }
            elseif ($ageDays -gt ($KrbtgtMaxAgeDays / 2)) { $status = "WARNING" }
            else { $status = "PASS" }
        }

        $results += New-ADCheckResult -CheckId "AD-23" -Name "KrbtgtPasswordAge" `
            -Title "Renouvellement du mot de passe du compte krbtgt" `
            -Category $cat -AnssiRef "ANSSI vuln1_krbtgt" -Severity "Critique" -Status $status `
            -Comment $comment `
            -Recommendation "Renouveler le mot de passe du compte krbtgt au moins une fois par an, et deux fois de suite (en respectant la duree de vie des tickets entre les deux) apres toute suspicion de compromission : c'est la seule facon d'invalider les Golden Tickets." `
            -Details "PasswordLastSet=$($krbtgt.PasswordLastSet)"
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-23" -Name "KrbtgtPasswordAge" `
            -Title "Renouvellement du mot de passe du compte krbtgt" `
            -Category $cat -AnssiRef "ANSSI vuln1_krbtgt" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Lecture du compte krbtgt impossible : $($_.Exception.Message)" `
            -Recommendation "Verifier les droits de lecture sur le compte krbtgt."
    }

    # =========================================================================
    # AD-24 : Delegation non contrainte hors controleurs de domaine
    # =========================================================================
    try {
        $unconstrained = @(Get-ADObject -LDAPFilter "(&(|(objectCategory=person)(objectCategory=computer))(userAccountControl:1.2.840.113556.1.4.803:=524288))" `
                            -Server $srv -Properties sAMAccountName, primaryGroupID, objectClass -ErrorAction Stop)
        $offenders = @($unconstrained | Where-Object { -not (Test-IsDomainController -Object $_) })

        $status = if ($offenders.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-24" -Name "UnconstrainedDelegation" `
            -Title "Delegation Kerberos non contrainte hors controleurs de domaine" `
            -Category $cat -AnssiRef "ANSSI vuln1_delegation_t4d" -Severity "Critique" -Status $status `
            -Comment "$($offenders.Count) objet(s) hors DC sont autorises a la delegation non contrainte." `
            -Recommendation "Supprimer la delegation non contrainte : tout serveur ainsi configure conserve en memoire les TGT des utilisateurs qui s'y connectent, y compris ceux des administrateurs du domaine. Utiliser une delegation contrainte ou, mieux, une delegation basee sur les ressources." `
            -Details @($offenders | ForEach-Object { "$($_.sAMAccountName) [$($_.objectClass)]" }) -AffectedCount $offenders.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-24" -Name "UnconstrainedDelegation" `
            -Title "Delegation Kerberos non contrainte hors controleurs de domaine" `
            -Category $cat -AnssiRef "ANSSI vuln1_delegation_t4d" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Recherche impossible : $($_.Exception.Message)" -Recommendation "Verifier les droits de lecture de l'annuaire."
    }

    # =========================================================================
    # AD-25 : Delegation contrainte avec transition de protocole
    # =========================================================================
    try {
        $protocolTransition = @(Get-ADObject -LDAPFilter "(&(|(objectCategory=person)(objectCategory=computer))(userAccountControl:1.2.840.113556.1.4.803:=16777216))" `
                                -Server $srv -Properties sAMAccountName, objectClass, "msDS-AllowedToDelegateTo" -ErrorAction Stop)

        $status = if ($protocolTransition.Count -eq 0) { "PASS" } else { "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-25" -Name "ConstrainedDelegationProtocolTransition" `
            -Title "Delegation contrainte avec transition de protocole (S4U2Self)" `
            -Category $cat -AnssiRef "ANSSI vuln2_delegation_t2a4d" -Severity "Majeur" -Status $status `
            -Comment "$($protocolTransition.Count) objet(s) configures en delegation contrainte avec transition de protocole." `
            -Recommendation "Restreindre la transition de protocole (option 'Utiliser n'importe quel protocole d'authentification') : elle permet au service d'obtenir un ticket au nom de n'importe quel utilisateur sans que celui-ci se soit authentifie. Preferer 'Utiliser Kerberos uniquement' ou une delegation basee sur les ressources." `
            -Details @($protocolTransition | ForEach-Object { "$($_.sAMAccountName) -> $(@($_.'msDS-AllowedToDelegateTo') -join ',')" }) `
            -AffectedCount $protocolTransition.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-25" -Name "ConstrainedDelegationProtocolTransition" `
            -Title "Delegation contrainte avec transition de protocole (S4U2Self)" `
            -Category $cat -AnssiRef "ANSSI vuln2_delegation_t2a4d" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Recherche impossible : $($_.Exception.Message)" -Recommendation "Verifier les droits de lecture de l'annuaire."
    }

    # =========================================================================
    # AD-26 : Delegation basee sur les ressources (RBCD)
    # =========================================================================
    try {
        $rbcd = @(Get-ADObject -LDAPFilter "(msDS-AllowedToActOnBehalfOfOtherIdentity=*)" -Server $srv `
                    -Properties sAMAccountName, objectClass -ErrorAction Stop)

        $status = if ($rbcd.Count -eq 0) { "PASS" } else { "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-26" -Name "ResourceBasedConstrainedDelegation" `
            -Title "Delegation contrainte basee sur les ressources (RBCD)" `
            -Category $cat -AnssiRef "ANSSI vuln2_delegation_rbcd" -Severity "Majeur" -Status $status `
            -Comment "$($rbcd.Count) objet(s) portent l'attribut msDS-AllowedToActOnBehalfOfOtherIdentity." `
            -Recommendation "Inventorier et justifier chaque delegation basee sur les ressources : un attaquant capable d'ecrire cet attribut sur un serveur (droit d'ecriture ou creation de compte machine) obtient une prise de controle complete de ce serveur." `
            -Details @($rbcd | ForEach-Object { "$($_.sAMAccountName) [$($_.objectClass)]" }) -AffectedCount $rbcd.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-26" -Name "ResourceBasedConstrainedDelegation" `
            -Title "Delegation contrainte basee sur les ressources (RBCD)" `
            -Category $cat -AnssiRef "ANSSI vuln2_delegation_rbcd" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Recherche impossible : $($_.Exception.Message)" -Recommendation "Verifier les droits de lecture de l'annuaire."
    }

    # =========================================================================
    # AD-27 : Algorithmes de chiffrement Kerberos autorises
    # =========================================================================
    try {
        # Comptes de service (porteurs de SPN) : RC4/DES encore acceptes ?
        $spnAccounts = @(Get-ADUser -LDAPFilter "(&(servicePrincipalName=*)(!(sAMAccountName=krbtgt)))" -Server $srv `
                            -Properties sAMAccountName, "msDS-SupportedEncryptionTypes" -ErrorAction Stop)

        $weak = @()
        foreach ($a in $spnAccounts) {
            $etype = $a."msDS-SupportedEncryptionTypes"
            if ($null -eq $etype) {
                $weak += "$($a.sAMAccountName) (attribut non defini : RC4 par defaut)"
            }
            else {
                $v = [int]$etype
                # 0x1 = DES-CRC, 0x2 = DES-MD5, 0x4 = RC4-HMAC
                if (($v -band 0x7) -ne 0) { $weak += "$($a.sAMAccountName) (msDS-SupportedEncryptionTypes=$v)" }
            }
        }

        $status = if ($spnAccounts.Count -eq 0) { "PASS" } elseif ($weak.Count -eq 0) { "PASS" } elseif ($weak.Count -le 5) { "WARNING" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-27" -Name "KerberosEncryptionTypes" `
            -Title "Algorithmes de chiffrement Kerberos des comptes de service" `
            -Category $cat -AnssiRef "ANSSI vuln2_kerberos_rc4" -Severity "Majeur" -Status $status `
            -Comment "$($weak.Count) compte(s) de service sur $($spnAccounts.Count) acceptent encore DES ou RC4." `
            -Recommendation "Positionner msDS-SupportedEncryptionTypes a AES uniquement (valeur 24) sur les comptes de service et les controleurs de domaine, apres validation de la compatibilite applicative : RC4 facilite le kerberoasting et les attaques par overpass-the-hash." `
            -Details $weak -AffectedCount $weak.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-27" -Name "KerberosEncryptionTypes" `
            -Title "Algorithmes de chiffrement Kerberos des comptes de service" `
            -Category $cat -AnssiRef "ANSSI vuln2_kerberos_rc4" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Recherche impossible : $($_.Exception.Message)" -Recommendation "Verifier les droits de lecture de l'annuaire."
    }

    # =========================================================================
    # AD-28 : Duree de vie des tickets Kerberos
    # =========================================================================
    $tmpl = Get-ADGpoSecurityTemplate -Context $Context -GpoGuid "{31B2F340-016D-11D2-945F-00C04FB984F9}"
    if ($tmpl -and $tmpl.ContainsKey("Kerberos Policy")) {
        $kp = $tmpl["Kerberos Policy"]
        $maxTicketAge   = if ($kp.ContainsKey("MaxTicketAge"))   { [int]$kp["MaxTicketAge"] }   else { 10 }
        $maxRenewAge    = if ($kp.ContainsKey("MaxRenewAge"))    { [int]$kp["MaxRenewAge"] }    else { 7 }
        $maxServiceAge  = if ($kp.ContainsKey("MaxServiceAge"))  { [int]$kp["MaxServiceAge"] }  else { 600 }
        $validateClient = if ($kp.ContainsKey("TicketValidateClient")) { [int]$kp["TicketValidateClient"] } else { 1 }

        $issues = @()
        if ($maxTicketAge -gt 10) { $issues += "MaxTicketAge=$maxTicketAge h (max recommande : 10 h)" }
        if ($maxRenewAge -gt 7)   { $issues += "MaxRenewAge=$maxRenewAge jours (max recommande : 7 jours)" }
        if ($maxServiceAge -gt 600) { $issues += "MaxServiceAge=$maxServiceAge min (max recommande : 600 min)" }
        if ($validateClient -ne 1) { $issues += "TicketValidateClient desactive" }

        $status = if ($issues.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-28" -Name "KerberosTicketLifetime" `
            -Title "Duree de vie et validation des tickets Kerberos" `
            -Category $cat -AnssiRef "ANSSI vuln2_kerberos_ticket_lifetime" -Severity "Mineur" -Status $status `
            -Comment "MaxTicketAge=$maxTicketAge h, MaxRenewAge=$maxRenewAge j, MaxServiceAge=$maxServiceAge min, TicketValidateClient=$validateClient." `
            -Recommendation "Conserver les valeurs par defaut de la politique Kerberos (TGT 10 heures, renouvellement 7 jours, ticket de service 600 minutes, validation du client activee) : les allonger prolonge d'autant la validite des tickets voles." `
            -Details $issues -AffectedCount $issues.Count
    }
    else {
        $results += New-ADCheckResult -CheckId "AD-28" -Name "KerberosTicketLifetime" `
            -Title "Duree de vie et validation des tickets Kerberos" `
            -Category $cat -AnssiRef "ANSSI vuln2_kerberos_ticket_lifetime" -Severity "Mineur" -Status "UNKNOWN" `
            -Comment "Modele de securite de la Default Domain Policy illisible depuis SYSVOL ($($Context.SysvolPath))." `
            -Recommendation "Verifier l'acces au partage SYSVOL, ou controler manuellement la politique Kerberos de la Default Domain Policy."
    }

    # =========================================================================
    # AD-29 : Comptes de service kerberoastables
    # =========================================================================
    try {
        $spnUsers = @(Get-ADUser -LDAPFilter "(&(servicePrincipalName=*)(!(sAMAccountName=krbtgt))(!(userAccountControl:1.2.840.113556.1.4.803:=2)))" `
                        -Server $srv -Properties sAMAccountName, PasswordLastSet, servicePrincipalName, adminCount -ErrorAction Stop)

        $limit = (Get-Date).AddDays(-$ServiceAccountPasswordMaxAgeDays)
        $risky = @()
        foreach ($u in $spnUsers) {
            if ($null -eq $u.PasswordLastSet) { $risky += "$($u.sAMAccountName) (mot de passe jamais defini)" }
            elseif ($u.PasswordLastSet -lt $limit) { $risky += "$($u.sAMAccountName) ($([int]((Get-Date) - $u.PasswordLastSet).TotalDays) jours)" }
        }

        $status = if ($spnUsers.Count -eq 0) { "PASS" } elseif ($risky.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-29" -Name "KerberoastableServiceAccounts" `
            -Title "Comptes de service kerberoastables a mot de passe ancien" `
            -Category $cat -AnssiRef "ANSSI vuln2_spn_password_age" -Severity "Majeur" -Status $status `
            -Comment "$($risky.Count) compte(s) de service sur $($spnUsers.Count) ont un mot de passe de plus de $ServiceAccountPasswordMaxAgeDays jours." `
            -Recommendation "Attribuer aux comptes de service porteurs de SPN un mot de passe aleatoire d'au moins 32 caracteres, renouvele annuellement, ou les migrer vers des gMSA : leur ticket de service est dechiffrable hors ligne par tout utilisateur du domaine." `
            -Details $risky -AffectedCount $risky.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-29" -Name "KerberoastableServiceAccounts" `
            -Title "Comptes de service kerberoastables a mot de passe ancien" `
            -Category $cat -AnssiRef "ANSSI vuln2_spn_password_age" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Recherche impossible : $($_.Exception.Message)" -Recommendation "Verifier les droits de lecture de l'annuaire."
    }

    # =========================================================================
    # AD-30 : Utilisation de comptes de service geres (gMSA)
    # =========================================================================
    try {
        $gmsa = @(Get-ADServiceAccount -Filter * -Server $srv -ErrorAction Stop)
        $spnUserCount = 0
        try {
            $spnUserCount = @(Get-ADUser -LDAPFilter "(&(servicePrincipalName=*)(!(sAMAccountName=krbtgt)))" -Server $srv -ErrorAction Stop).Count
        }
        catch { }

        $status = "PASS"
        $comment = "$($gmsa.Count) compte(s) de service gere(s) declare(s) pour $spnUserCount compte(s) de service classique(s)."
        if ($gmsa.Count -eq 0 -and $spnUserCount -gt 0) { $status = "FAIL" }
        elseif ($spnUserCount -gt $gmsa.Count) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-30" -Name "GroupManagedServiceAccounts" `
            -Title "Utilisation de comptes de service geres (gMSA)" `
            -Category $cat -AnssiRef "ANSSI vuln3_no_gmsa / DAT-NT-017" -Severity "Mineur" -Status $status `
            -Comment $comment `
            -Recommendation "Migrer les comptes de service vers des gMSA : leur mot de passe est genere aleatoirement (240 caracteres), renouvele automatiquement tous les 30 jours et n'est jamais manipule par un administrateur." `
            -Details @($gmsa | ForEach-Object { $_.Name }) -AffectedCount $gmsa.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-30" -Name "GroupManagedServiceAccounts" `
            -Title "Utilisation de comptes de service geres (gMSA)" `
            -Category $cat -AnssiRef "ANSSI vuln3_no_gmsa" -Severity "Mineur" -Status "UNKNOWN" `
            -Comment "Enumeration des comptes de service geres impossible : $($_.Exception.Message)" `
            -Recommendation "Verifier les droits de lecture sur le conteneur Managed Service Accounts."
    }

    return $results
}
