# -----------------------------------------------------------------------------
# Fonction : Get-ADPrivilegedAccountsAudit
# Description : Controles ANSSI AD-01 a AD-12 - comptes et groupes a hauts
#               privileges (Tier 0). Couvre la composition des groupes
#               d'administration, la protection des comptes privilegies et
#               l'integrite du conteneur AdminSDHolder.
# Referentiel : ANSSI "Points de controle Active Directory" (niveaux 1 a 3)
#               et guide DAT-NT-017 "Recommandations relatives a Active Directory".
# -----------------------------------------------------------------------------

function Get-ADPrivilegedAccountsAudit {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$Context,

        # Seuils d'alerte (adaptables selon la taille du SI audite)
        [int]$MaxDomainAdmins = 5,
        [int]$PrivilegedPasswordMaxAgeDays = 365,
        [int]$InactivityDays = 90
    )

    $results = @()
    $srv = $Context.Server
    $cat = "Comptes a privileges"

    # --- Helpers locaux ------------------------------------------------------

    function Get-ADGroupBySid {
        param([string]$Sid)
        try { return Get-ADGroup -Identity $Sid -Server $srv -Properties DistinguishedName, Name -ErrorAction Stop }
        catch { return $null }
    }

    # Membres recursifs (regle LDAP_MATCHING_RULE_IN_CHAIN) d'une classe donnee
    function Get-ADMembersInChain {
        param($Group, [string]$ObjectClass = "user")
        if (-not $Group) { return @() }
        $dn = ConvertTo-ADFilterValue -Value $Group.DistinguishedName
        try {
            return @(Get-ADObject -LDAPFilter "(&(objectClass=$ObjectClass)(memberOf:1.2.840.113556.1.4.1941:=$dn))" `
                        -Server $srv `
                        -Properties sAMAccountName, userAccountControl, pwdLastSet, lastLogonTimestamp, servicePrincipalName, adminCount, objectClass `
                        -ErrorAction Stop)
        }
        catch { return @() }
    }

    function Get-UacFlag {
        param($Object, [int]$Flag)
        $uac = 0
        if ($null -ne $Object.userAccountControl) { $uac = [int]$Object.userAccountControl }
        return (($uac -band $Flag) -ne 0)
    }

    function ConvertFrom-ADFileTime {
        param($Value)
        if ($null -eq $Value -or [long]$Value -le 0) { return $null }
        try { return [datetime]::FromFileTime([long]$Value) } catch { return $null }
    }

    # --- Recuperation des groupes privilegies --------------------------------

    $dsid = $Context.DomainSID
    $rsid = $Context.RootDomainSID

    $grpDomainAdmins   = Get-ADGroupBySid "$dsid-512"
    $grpEnterpriseAdm  = Get-ADGroupBySid "$rsid-519"
    $grpSchemaAdmins   = Get-ADGroupBySid "$rsid-518"
    $grpAdministrators = Get-ADGroupBySid "S-1-5-32-544"
    $grpProtectedUsers = Get-ADGroupBySid "$dsid-525"

    $operatorGroups = @(
        @{ Sid = "S-1-5-32-548"; Label = "Account Operators" },
        @{ Sid = "S-1-5-32-549"; Label = "Server Operators" },
        @{ Sid = "S-1-5-32-550"; Label = "Print Operators" },
        @{ Sid = "S-1-5-32-551"; Label = "Backup Operators" }
    )

    # Ensemble consolide des comptes utilisateurs privilegies (Tier 0)
    $tier0Groups = @($grpDomainAdmins, $grpEnterpriseAdm, $grpSchemaAdmins, $grpAdministrators) |
                        Where-Object { $null -ne $_ }

    $privilegedUsers = @{}
    foreach ($g in $tier0Groups) {
        foreach ($m in (Get-ADMembersInChain -Group $g -ObjectClass "user")) {
            if (-not $privilegedUsers.ContainsKey($m.DistinguishedName)) {
                $privilegedUsers[$m.DistinguishedName] = $m
            }
        }
    }
    $privUserList = @($privilegedUsers.Values)

    # =========================================================================
    # AD-01 : Composition du groupe Admins du domaine
    # =========================================================================
    if ($grpDomainAdmins) {
        $daUsers     = Get-ADMembersInChain -Group $grpDomainAdmins -ObjectClass "user"
        $daComputers = Get-ADMembersInChain -Group $grpDomainAdmins -ObjectClass "computer"
        $names = @($daUsers | ForEach-Object { $_.sAMAccountName })

        $status = "PASS"
        $comment = "$($daUsers.Count) compte(s) utilisateur dans Admins du domaine."

        if ($daComputers.Count -gt 0) {
            $status = "FAIL"
            $comment += " $($daComputers.Count) compte(s) machine y sont egalement membres."
        }
        elseif ($daUsers.Count -gt (2 * $MaxDomainAdmins)) { $status = "FAIL" }
        elseif ($daUsers.Count -gt $MaxDomainAdmins) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-01" -Name "DomainAdminsMembership" `
            -Title "Nombre et nature des membres du groupe Admins du domaine" `
            -Category $cat -AnssiRef "ANSSI vuln1_privileged_members / DAT-NT-017 R1" `
            -Severity "Critique" -Status $status `
            -Comment $comment `
            -Recommendation "Limiter le groupe Admins du domaine a un nombre minimal de comptes nominatifs d'administration (cible : $MaxDomainAdmins au maximum). Aucun compte de service ni compte machine ne doit y figurer." `
            -Details ($names + @($daComputers | ForEach-Object { "[machine] $($_.sAMAccountName)" })) `
            -AffectedCount ($daUsers.Count + $daComputers.Count)
    }
    else {
        $results += New-ADCheckResult -CheckId "AD-01" -Name "DomainAdminsMembership" `
            -Title "Nombre et nature des membres du groupe Admins du domaine" `
            -Category $cat -AnssiRef "ANSSI vuln1_privileged_members" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Groupe Admins du domaine ($dsid-512) introuvable ou inaccessible." `
            -Recommendation "Verifier les droits de lecture de l'annuaire du compte executant l'audit."
    }

    # =========================================================================
    # AD-02 : Groupe Administrateurs de l'entreprise vide en regime permanent
    # =========================================================================
    if ($grpEnterpriseAdm) {
        $eaUsers = Get-ADMembersInChain -Group $grpEnterpriseAdm -ObjectClass "user"
        $status = "PASS"
        if ($eaUsers.Count -gt 1) { $status = "FAIL" }
        elseif ($eaUsers.Count -eq 1) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-02" -Name "EnterpriseAdminsMembership" `
            -Title "Groupe Administrateurs de l'entreprise vide hors operations" `
            -Category $cat -AnssiRef "ANSSI vuln1_privileged_members" -Severity "Critique" -Status $status `
            -Comment "$($eaUsers.Count) membre(s) permanent(s) dans Administrateurs de l'entreprise." `
            -Recommendation "Le groupe Administrateurs de l'entreprise doit rester vide en dehors des operations exceptionnelles sur la foret ; les comptes y sont ajoutes temporairement puis retires." `
            -Details @($eaUsers | ForEach-Object { $_.sAMAccountName }) -AffectedCount $eaUsers.Count
    }
    else {
        $results += New-ADCheckResult -CheckId "AD-02" -Name "EnterpriseAdminsMembership" `
            -Title "Groupe Administrateurs de l'entreprise vide hors operations" `
            -Category $cat -AnssiRef "ANSSI vuln1_privileged_members" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Groupe Administrateurs de l'entreprise inaccessible (domaine racine de foret non joignable ?)." `
            -Recommendation "Auditer ce groupe depuis le domaine racine de la foret."
    }

    # =========================================================================
    # AD-03 : Groupe Administrateurs du schema vide en regime permanent
    # =========================================================================
    if ($grpSchemaAdmins) {
        $saUsers = Get-ADMembersInChain -Group $grpSchemaAdmins -ObjectClass "user"
        $status = "PASS"
        if ($saUsers.Count -gt 1) { $status = "FAIL" }
        elseif ($saUsers.Count -eq 1) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-03" -Name "SchemaAdminsMembership" `
            -Title "Groupe Administrateurs du schema vide hors operations" `
            -Category $cat -AnssiRef "ANSSI vuln1_privileged_members" -Severity "Critique" -Status $status `
            -Comment "$($saUsers.Count) membre(s) permanent(s) dans Administrateurs du schema." `
            -Recommendation "Le groupe Administrateurs du schema ne doit contenir aucun membre permanent : n'y ajouter un compte que pendant une extension de schema, puis le retirer." `
            -Details @($saUsers | ForEach-Object { $_.sAMAccountName }) -AffectedCount $saUsers.Count
    }
    else {
        $results += New-ADCheckResult -CheckId "AD-03" -Name "SchemaAdminsMembership" `
            -Title "Groupe Administrateurs du schema vide hors operations" `
            -Category $cat -AnssiRef "ANSSI vuln1_privileged_members" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Groupe Administrateurs du schema inaccessible." `
            -Recommendation "Auditer ce groupe depuis le domaine racine de la foret."
    }

    # =========================================================================
    # AD-04 : Composition du groupe Administrateurs (builtin)
    # =========================================================================
    if ($grpAdministrators) {
        $blUsers = Get-ADMembersInChain -Group $grpAdministrators -ObjectClass "user"
        $status = "PASS"
        if ($blUsers.Count -gt (2 * $MaxDomainAdmins)) { $status = "FAIL" }
        elseif ($blUsers.Count -gt $MaxDomainAdmins) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-04" -Name "BuiltinAdministratorsMembership" `
            -Title "Composition du groupe Administrateurs integre du domaine" `
            -Category $cat -AnssiRef "ANSSI vuln1_privileged_members / DAT-NT-017 R1" -Severity "Critique" -Status $status `
            -Comment "$($blUsers.Count) compte(s) utilisateur disposent des droits d'administration du domaine via BUILTIN\Administrators." `
            -Recommendation "Le groupe Administrateurs integre ne doit contenir que Admins du domaine, Administrateurs de l'entreprise et le compte Administrateur integre. Retirer tout autre principal." `
            -Details @($blUsers | ForEach-Object { $_.sAMAccountName }) -AffectedCount $blUsers.Count
    }

    # =========================================================================
    # AD-05 : Groupes d'operateurs integres vides
    # =========================================================================
    $operatorMembers = @()
    $operatorCount = 0
    $operatorUnknown = $false

    foreach ($og in $operatorGroups) {
        $g = Get-ADGroupBySid $og.Sid
        if (-not $g) { $operatorUnknown = $true; continue }
        $m = Get-ADMembersInChain -Group $g -ObjectClass "user"
        $operatorCount += $m.Count
        foreach ($u in $m) { $operatorMembers += "$($og.Label) : $($u.sAMAccountName)" }
    }

    # DnsAdmins ne possede pas de SID bien connu : recherche par nom
    try {
        $dnsAdmins = Get-ADGroup -LDAPFilter "(sAMAccountName=DnsAdmins)" -Server $srv -ErrorAction Stop | Select-Object -First 1
        if ($dnsAdmins) {
            $m = Get-ADMembersInChain -Group $dnsAdmins -ObjectClass "user"
            $operatorCount += $m.Count
            foreach ($u in $m) { $operatorMembers += "DnsAdmins : $($u.sAMAccountName)" }
        }
    }
    catch { }

    $status = if ($operatorUnknown -and $operatorCount -eq 0) { "UNKNOWN" } elseif ($operatorCount -eq 0) { "PASS" } else { "FAIL" }

    $results += New-ADCheckResult -CheckId "AD-05" -Name "BuiltinOperatorGroups" `
        -Title "Groupes d'operateurs integres (Account/Server/Print/Backup Operators, DnsAdmins) vides" `
        -Category $cat -AnssiRef "ANSSI vuln1_privileged_members / vuln2_dnsadmins" -Severity "Critique" -Status $status `
        -Comment "$operatorCount compte(s) membre(s) des groupes d'operateurs integres." `
        -Recommendation "Vider les groupes Operateurs de compte, Operateurs de serveur, Operateurs d'impression, Operateurs de sauvegarde et DnsAdmins : ils permettent une elevation vers l'administration du domaine. Utiliser des delegations fines a la place." `
        -Details $operatorMembers -AffectedCount $operatorCount

    # =========================================================================
    # AD-06 : Utilisation du groupe Utilisateurs proteges
    # =========================================================================
    if ($grpProtectedUsers -and $privUserList.Count -gt 0) {
        $protectedMembers = Get-ADMembersInChain -Group $grpProtectedUsers -ObjectClass "user"
        $protectedDns = @($protectedMembers | ForEach-Object { $_.DistinguishedName })
        $notProtected = @($privUserList | Where-Object { $protectedDns -notcontains $_.DistinguishedName })

        $status = "PASS"
        if ($notProtected.Count -eq $privUserList.Count) { $status = "FAIL" }
        elseif ($notProtected.Count -gt 0) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-06" -Name "ProtectedUsersGroup" `
            -Title "Comptes privilegies membres du groupe Utilisateurs proteges" `
            -Category $cat -AnssiRef "ANSSI vuln3_admin_accounts_not_protected" -Severity "Majeur" -Status $status `
            -Comment "$($notProtected.Count) compte(s) privilegie(s) sur $($privUserList.Count) ne sont pas membres de Utilisateurs proteges." `
            -Recommendation "Placer les comptes d'administration dans le groupe Utilisateurs proteges (niveau fonctionnel 2012 R2 minimum) : NTLM, delegation, DES/RC4 et mise en cache des secrets y sont interdits." `
            -Details @($notProtected | ForEach-Object { $_.sAMAccountName }) -AffectedCount $notProtected.Count
    }
    else {
        $results += New-ADCheckResult -CheckId "AD-06" -Name "ProtectedUsersGroup" `
            -Title "Comptes privilegies membres du groupe Utilisateurs proteges" `
            -Category $cat -AnssiRef "ANSSI vuln3_admin_accounts_not_protected" -Severity "Majeur" -Status "UNKNOWN" `
            -Comment "Groupe Utilisateurs proteges introuvable ou aucun compte privilegie identifie." `
            -Recommendation "Verifier le niveau fonctionnel du domaine (2012 R2 minimum) puis utiliser le groupe Utilisateurs proteges."
    }

    # =========================================================================
    # AD-07 : Comptes privilegies non delegables (flag NOT_DELEGATED)
    # =========================================================================
    if ($privUserList.Count -gt 0) {
        $NOT_DELEGATED = 0x100000
        $delegable = @($privUserList | Where-Object { -not (Get-UacFlag -Object $_ -Flag $NOT_DELEGATED) })

        $status = "PASS"
        if ($delegable.Count -eq $privUserList.Count) { $status = "FAIL" }
        elseif ($delegable.Count -gt 0) { $status = "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-07" -Name "SensitiveAndNotDelegated" `
            -Title "Comptes privilegies marques comme sensibles et non delegables" `
            -Category $cat -AnssiRef "ANSSI vuln2_admin_accounts_not_sensitive" -Severity "Majeur" -Status $status `
            -Comment "$($delegable.Count) compte(s) privilegie(s) sur $($privUserList.Count) sont delegables (option 'Le compte est sensible et ne peut pas etre delegue' absente)." `
            -Recommendation "Activer l'option 'Le compte est sensible et ne peut pas etre delegue' (UF_NOT_DELEGATED) sur tous les comptes d'administration afin d'empecher la reutilisation de leurs tickets par un serveur compromis." `
            -Details @($delegable | ForEach-Object { $_.sAMAccountName }) -AffectedCount $delegable.Count
    }

    # =========================================================================
    # AD-08 : Anciennete des mots de passe des comptes privilegies
    # =========================================================================
    if ($privUserList.Count -gt 0) {
        $limit = (Get-Date).AddDays(-$PrivilegedPasswordMaxAgeDays)
        $stale = @()
        foreach ($u in $privUserList) {
            $pls = ConvertFrom-ADFileTime $u.pwdLastSet
            if ($null -eq $pls) { $stale += "$($u.sAMAccountName) (jamais defini)" }
            elseif ($pls -lt $limit) { $stale += "$($u.sAMAccountName) ($([int]((Get-Date) - $pls).TotalDays) jours)" }
        }

        $status = if ($stale.Count -eq 0) { "PASS" } elseif ($stale.Count -le 2) { "WARNING" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-08" -Name "PrivilegedPasswordAge" `
            -Title "Renouvellement des mots de passe des comptes privilegies" `
            -Category $cat -AnssiRef "ANSSI vuln2_admin_password_age / DAT-NT-017" -Severity "Majeur" -Status $status `
            -Comment "$($stale.Count) compte(s) privilegie(s) avec un mot de passe de plus de $PrivilegedPasswordMaxAgeDays jours." `
            -Recommendation "Renouveler les mots de passe des comptes d'administration au moins une fois par an (et immediatement apres tout depart ou suspicion de compromission)." `
            -Details $stale -AffectedCount $stale.Count
    }

    # =========================================================================
    # AD-09 : Comptes privilegies inactifs
    # =========================================================================
    if ($privUserList.Count -gt 0) {
        $limit = (Get-Date).AddDays(-$InactivityDays)
        $inactive = @()
        foreach ($u in $privUserList) {
            $llt = ConvertFrom-ADFileTime $u.lastLogonTimestamp
            if ($null -eq $llt) { $inactive += "$($u.sAMAccountName) (aucune connexion enregistree)" }
            elseif ($llt -lt $limit) { $inactive += "$($u.sAMAccountName) (derniere connexion $($llt.ToString('yyyy-MM-dd')))" }
        }

        $status = if ($inactive.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-09" -Name "PrivilegedInactiveAccounts" `
            -Title "Comptes privilegies inactifs encore actifs dans l'annuaire" `
            -Category $cat -AnssiRef "ANSSI vuln2_admin_accounts_inactive" -Severity "Majeur" -Status $status `
            -Comment "$($inactive.Count) compte(s) privilegie(s) sans connexion depuis plus de $InactivityDays jours." `
            -Recommendation "Desactiver puis supprimer les comptes d'administration inutilises depuis plus de $InactivityDays jours : ils elargissent la surface d'attaque sans etre surveilles." `
            -Details $inactive -AffectedCount $inactive.Count
    }

    # =========================================================================
    # AD-10 : Integrite des ACL du conteneur AdminSDHolder
    # =========================================================================
    $adminSdHolderDn = "CN=AdminSDHolder,CN=System,$($Context.DomainDN)"
    try {
        $acl = Get-Acl -Path "AD:\$adminSdHolderDn" -ErrorAction Stop

        $suspicious = @()
        foreach ($ace in $acl.Access) {
            if ($ace.AccessControlType -ne 'Allow') { continue }
            $trustee = "$($ace.IdentityReference)"
            if (Test-ADPrivilegedTrustee -Trustee $trustee) { continue }
            $rights = "$($ace.ActiveDirectoryRights)"
            if ($rights -match 'GenericAll|WriteDacl|WriteOwner|WriteProperty|ExtendedRight|GenericWrite') {
                $suspicious += "$trustee -> $rights"
            }
        }

        $status = if ($suspicious.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-10" -Name "AdminSDHolderAcl" `
            -Title "Permissions non standard sur le conteneur AdminSDHolder" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_adminsdholder" -Severity "Critique" -Status $status `
            -Comment "$($suspicious.Count) ACE non standard en autorisation sur AdminSDHolder." `
            -Recommendation "Retirer toute delegation ajoutee sur AdminSDHolder : ses ACL sont recopiees toutes les 60 minutes par SDProp sur l'ensemble des objets proteges (comptes et groupes d'administration)." `
            -Details $suspicious -AffectedCount $suspicious.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-10" -Name "AdminSDHolderAcl" `
            -Title "Permissions non standard sur le conteneur AdminSDHolder" `
            -Category $cat -AnssiRef "ANSSI vuln1_permissions_adminsdholder" -Severity "Critique" -Status "UNKNOWN" `
            -Comment "Lecture des ACL de AdminSDHolder impossible : $($_.Exception.Message)" `
            -Recommendation "Executer l'audit avec un compte disposant du droit de lecture des descripteurs de securite de l'annuaire."
    }

    # =========================================================================
    # AD-11 : Comptes orphelins portant adminCount = 1
    # =========================================================================
    try {
        $adminCountUsers = @(Get-ADUser -LDAPFilter "(&(objectClass=user)(adminCount=1))" -Server $srv `
                                -Properties sAMAccountName, adminCount, Enabled -ErrorAction Stop)
        $privDns = @($privUserList | ForEach-Object { $_.DistinguishedName })
        $orphans = @($adminCountUsers | Where-Object { $privDns -notcontains $_.DistinguishedName })

        $status = if ($orphans.Count -eq 0) { "PASS" } else { "WARNING" }

        $results += New-ADCheckResult -CheckId "AD-11" -Name "OrphanAdminCountAccounts" `
            -Title "Comptes avec adminCount=1 hors des groupes privilegies" `
            -Category $cat -AnssiRef "ANSSI vuln3_admincount_orphan" -Severity "Mineur" -Status $status `
            -Comment "$($orphans.Count) compte(s) conservent adminCount=1 alors qu'ils ne sont plus membres d'un groupe protege." `
            -Recommendation "Reinitialiser adminCount et restaurer l'heritage des ACL sur ces comptes : ils conservent sinon des permissions figees et echappent aux delegations normales." `
            -Details @($orphans | ForEach-Object { $_.sAMAccountName }) -AffectedCount $orphans.Count
    }
    catch {
        $results += New-ADCheckResult -CheckId "AD-11" -Name "OrphanAdminCountAccounts" `
            -Title "Comptes avec adminCount=1 hors des groupes privilegies" `
            -Category $cat -AnssiRef "ANSSI vuln3_admincount_orphan" -Severity "Mineur" -Status "UNKNOWN" `
            -Comment "Recherche des comptes adminCount=1 impossible : $($_.Exception.Message)" `
            -Recommendation "Verifier les droits de lecture de l'annuaire."
    }

    # =========================================================================
    # AD-12 : Comptes privilegies porteurs d'un SPN (kerberoasting Tier 0)
    # =========================================================================
    if ($privUserList.Count -gt 0) {
        $withSpn = @($privUserList | Where-Object { $_.servicePrincipalName -and @($_.servicePrincipalName).Count -gt 0 })
        $status = if ($withSpn.Count -eq 0) { "PASS" } else { "FAIL" }

        $results += New-ADCheckResult -CheckId "AD-12" -Name "PrivilegedAccountsWithSpn" `
            -Title "Comptes privilegies exposant un SPN (kerberoasting sur Tier 0)" `
            -Category $cat -AnssiRef "ANSSI vuln1_priv_spn" -Severity "Critique" -Status $status `
            -Comment "$($withSpn.Count) compte(s) privilegie(s) exposent un SPN et sont donc kerberoastables." `
            -Recommendation "Aucun compte membre d'un groupe d'administration ne doit porter de SPN : tout utilisateur du domaine peut demander un ticket de service et casser son mot de passe hors ligne. Migrer ces services vers des comptes dedies non privilegies ou des gMSA." `
            -Details @($withSpn | ForEach-Object { "$($_.sAMAccountName) [$(@($_.servicePrincipalName) -join ',')]" }) `
            -AffectedCount $withSpn.Count
    }

    return $results
}
