﻿function Get-InstalledApplications {
    [CmdletBinding()]
    param()

    $Paths = @(
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )

    $AppList = foreach ($path in $Paths) {
        Get-ItemProperty -Path $path -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName } |
            Select-Object @{n = 'Name'           ; e = { $_.DisplayName     }},
                          @{n = 'Version'        ; e = { $_.DisplayVersion   }},
                          @{n = 'Publisher'      ; e = { $_.Publisher        }},
                          @{n = 'InstallLocation'; e = { $_.InstallLocation  }}
    }

    $AppList | Sort-Object Name, Version
}


function Get-AppUpgrade {
    <#
    .SYNOPSIS
        Liste les applications disposant d'une mise a jour via WinGet.
    .DESCRIPTION
        WinGet n'est disponible que sur Windows 10 1809 (build 17763) et
        ulterieur cote client, et Windows Server 2025 cote serveur. Le prerequis
        est evalue sur le numero de build via Get-OSVersionInfo, et non sur le
        libelle de l'OS qui est localise et donc non comparable.

        La fonction n'installe rien et ne pose aucune question : elle renvoie
        $null si WinGet est indisponible, afin de rester utilisable dans un
        audit automatise.
    #>
    [CmdletBinding()]
    param(
        # Contexte OS deja collecte (evite un second appel a Get-OSVersionInfo)
        [Parameter(Mandatory = $false)]$OSInfo
    )

    if (-not $OSInfo) {
        try { $OSInfo = Get-OSVersionInfo } catch { }
    }

    if ($OSInfo) {
        # Cote serveur, WinGet n'est fourni qu'a partir de Windows Server 2025 (build 26100)
        $minimumBuild = if ($OSInfo.IsServer) { 26100 } else { 17763 }

        if ([int]$OSInfo.Build -lt $minimumBuild) {
            Write-Verbose "WinGet non disponible sur $($OSInfo.DisplayName) (build $($OSInfo.Build) < $minimumBuild)."
            return $null
        }
    }

    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        Write-Warning "WinGet CLI n'est pas disponible sur ce systeme : verification des mises a jour applicatives ignoree."
        return $null
    }

    if (-not (Get-Command Get-WinGetPackage -ErrorAction SilentlyContinue)) {
        Write-Warning "Module 'Microsoft.WinGet.Client' absent : verification des mises a jour applicatives ignoree. Installer avec : Install-Module Microsoft.WinGet.Client -Scope CurrentUser"
        return $null
    }

    try {
        return Get-WinGetPackage -ErrorAction Stop |
            Where-Object { $_.IsUpdateAvailable -eq $true } |
            Select-Object Name, InstalledVersion, AvailableVersions
    }
    catch {
        Write-Warning "Interrogation de WinGet en echec : $($_.Exception.Message)"
        return $null
    }
}

