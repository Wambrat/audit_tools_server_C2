# -----------------------------------------------------------------------------
# Fonction : Get-OSVersionInfo / Get-OSSupportStatus
# Description : Identification dynamique de la version de Windows et evaluation
#               de son statut de support.
#
# Pourquoi ne pas se fier a Caption / ProductName :
#   - Win32_OperatingSystem.Version renvoie "10.0.x" y compris sur Windows 11 ;
#   - la valeur de registre ProductName annonce encore "Windows 10 Pro" sur
#     Windows 11 ;
#   - Caption est localise, donc toute comparaison textuelle ("Windows Server",
#     "Windows 10"...) casse selon la langue du systeme.
#
# La detection s'appuie donc sur des donnees numeriques et stables :
#   - le numero de build (CurrentBuildNumber) pour la famille et la version ;
#   - ProductType / InstallationType pour le role (client, serveur, Server Core) ;
#   - EditionID pour l'edition et la detection LTSC.
# -----------------------------------------------------------------------------

function Get-OSVersionInfo {
    [CmdletBinding()]
    param()

    process {
        $regPath = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
        $reg = $null
        try { $reg = Get-ItemProperty -Path $regPath -ErrorAction Stop } catch { }

        $os = $null
        try { $os = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop } catch { }

        # --- Build et UBR (revision mensuelle) -------------------------------
        $build = 0
        if ($reg -and $reg.CurrentBuildNumber) { $build = [int]$reg.CurrentBuildNumber }
        elseif ($os -and $os.BuildNumber) { $build = [int]$os.BuildNumber }

        $ubr = 0
        if ($reg -and $null -ne $reg.UBR) { $ubr = [int]$reg.UBR }

        # --- Role de la machine ----------------------------------------------
        # ProductType : 1 = poste de travail, 2 = controleur de domaine, 3 = serveur
        $productType = 1
        if ($os -and $os.ProductType) { $productType = [int]$os.ProductType }

        $installationType = ""
        if ($reg -and $reg.InstallationType) { $installationType = "$($reg.InstallationType)" }

        $isServer = ($productType -ne 1) -or ($installationType -match 'Server')
        $isServerCore = ($installationType -eq 'Server Core')

        # --- Edition ----------------------------------------------------------
        $editionId = ""
        if ($reg -and $reg.EditionID) { $editionId = "$($reg.EditionID)" }

        # EnterpriseS / IoTEnterpriseS identifient les canaux de maintenance a long terme
        $isLtsc = ($editionId -match '^(IoT)?EnterpriseS')

        # Editions dont le cycle de vie est allonge de 12 a 24 mois cote client
        $isEnterpriseChannel = ($editionId -match 'Enterprise|Education')

        # --- Version commerciale (24H2, 22H2...) -------------------------------
        $releaseLabel = ""
        if ($reg -and $reg.DisplayVersion) { $releaseLabel = "$($reg.DisplayVersion)" }
        elseif ($reg -and $reg.ReleaseId) { $releaseLabel = "$($reg.ReleaseId)" }

        # --- Famille de produit, deduite du build ------------------------------
        $productFamily = "Windows"
        if ($isServer) {
            # Cote serveur, le millesime est deduit du build ; on retombe sur le
            # libelle systeme si le build n'est pas connu.
            $serverByBuild = @{
                26100 = 'Windows Server 2025'
                25398 = 'Windows Server 23H2'
                20348 = 'Windows Server 2022'
                17763 = 'Windows Server 2019'
                14393 = 'Windows Server 2016'
                9600  = 'Windows Server 2012 R2'
                9200  = 'Windows Server 2012'
                7601  = 'Windows Server 2008 R2'
            }

            if ($serverByBuild.ContainsKey($build)) {
                $productFamily = $serverByBuild[$build]
            }
            elseif ($os -and "$($os.Caption)" -match 'Server\s+(\d{4})(\s*R2)?') {
                $productFamily = "Windows Server $($Matches[1])$(if ($Matches[2]) { ' R2' })"
            }
            else {
                $productFamily = "Windows Server (build $build)"
            }
        }
        else {
            if ($build -ge 22000) { $productFamily = "Windows 11" }
            elseif ($build -ge 10240) { $productFamily = "Windows 10" }
            elseif ($build -ge 9600) { $productFamily = "Windows 8.1" }
            elseif ($build -ge 9200) { $productFamily = "Windows 8" }
            elseif ($build -ge 7600) { $productFamily = "Windows 7" }
            elseif ($reg -and $reg.ProductName) { $productFamily = "$($reg.ProductName)" }
        }

        $displayName = $productFamily
        if ($releaseLabel) { $displayName += " $releaseLabel" }
        if ($isLtsc) { $displayName += " (LTSC)" }
        if ($isServerCore) { $displayName += " [Server Core]" }

        $installDate = $null
        if ($os -and $os.InstallDate) { $installDate = $os.InstallDate }

        return [PSCustomObject]@{
            DisplayName      = $displayName
            ProductFamily    = $productFamily
            ReleaseLabel     = $releaseLabel
            Caption          = if ($os) { "$($os.Caption)".Trim() } else { "" }
            Edition          = $editionId
            Build            = $build
            UBR              = $ubr
            FullVersion      = "10.0.$build.$ubr"
            Version          = if ($os) { "$($os.Version)" } else { "" }
            Architecture     = if ($os) { "$($os.OSArchitecture)" } else { "" }
            ProductType      = $productType
            InstallationType = $installationType
            IsServer         = $isServer
            IsServerCore     = $isServerCore
            IsDomainController = ($productType -eq 2)
            IsLTSC           = $isLtsc
            IsEnterprise     = $isEnterpriseChannel
            InstallDate      = $installDate
        }
    }
}

# -----------------------------------------------------------------------------
# Referentiel local de fin de support, utilise lorsque la consultation en ligne
# est desactivee ou indisponible. Les dates sont au format yyyy-MM-dd.
#   EolStandard   : editions Famille / Professionnel (client) ou fin de support
#                   etendu (serveur)
#   EolEnterprise : editions Entreprise / Education (client uniquement)
#   EolLtsc       : canal de maintenance a long terme, quand la build en dispose
# -----------------------------------------------------------------------------
function Get-OSSupportBaseline {
    [CmdletBinding()]
    param()

    return [PSCustomObject]@{
        # Date de derniere mise a jour du referentiel embarque
        AsOf = [datetime]'2026-05-01'

        Client = @{
            10240 = @{ Release = '1507'; EolStandard = '2017-05-09'; EolEnterprise = '2017-05-09'; EolLtsc = '2025-10-14' }
            10586 = @{ Release = '1511'; EolStandard = '2017-10-10'; EolEnterprise = '2018-04-10' }
            14393 = @{ Release = '1607'; EolStandard = '2018-04-10'; EolEnterprise = '2019-04-09'; EolLtsc = '2026-10-13' }
            15063 = @{ Release = '1703'; EolStandard = '2018-10-09'; EolEnterprise = '2019-10-08' }
            16299 = @{ Release = '1709'; EolStandard = '2019-04-09'; EolEnterprise = '2020-10-13' }
            17134 = @{ Release = '1803'; EolStandard = '2019-11-12'; EolEnterprise = '2021-05-11' }
            17763 = @{ Release = '1809'; EolStandard = '2020-11-10'; EolEnterprise = '2021-05-11'; EolLtsc = '2029-01-09' }
            18362 = @{ Release = '1903'; EolStandard = '2020-12-08'; EolEnterprise = '2020-12-08' }
            18363 = @{ Release = '1909'; EolStandard = '2021-05-11'; EolEnterprise = '2022-05-10' }
            19041 = @{ Release = '2004'; EolStandard = '2021-12-14'; EolEnterprise = '2021-12-14' }
            19042 = @{ Release = '20H2'; EolStandard = '2022-05-10'; EolEnterprise = '2023-05-09' }
            19043 = @{ Release = '21H1'; EolStandard = '2022-12-13'; EolEnterprise = '2022-12-13' }
            19044 = @{ Release = '21H2'; EolStandard = '2023-06-13'; EolEnterprise = '2024-06-11'; EolLtsc = '2027-01-12' }
            19045 = @{ Release = '22H2'; EolStandard = '2025-10-14'; EolEnterprise = '2025-10-14' }
            22000 = @{ Release = '21H2'; EolStandard = '2023-10-10'; EolEnterprise = '2024-10-08' }
            22621 = @{ Release = '22H2'; EolStandard = '2024-10-08'; EolEnterprise = '2025-10-14' }
            22631 = @{ Release = '23H2'; EolStandard = '2025-11-11'; EolEnterprise = '2026-11-10' }
            26100 = @{ Release = '24H2'; EolStandard = '2026-10-13'; EolEnterprise = '2027-10-12'; EolLtsc = '2029-10-09' }
            26200 = @{ Release = '25H2'; EolStandard = '2027-10-12'; EolEnterprise = '2028-10-10' }
        }

        Server = @{
            7601  = @{ Release = '2008 R2'; EolStandard = '2020-01-14' }
            9200  = @{ Release = '2012';    EolStandard = '2023-10-10' }
            9600  = @{ Release = '2012 R2'; EolStandard = '2023-10-10' }
            14393 = @{ Release = '2016';    EolStandard = '2027-01-12' }
            17763 = @{ Release = '2019';    EolStandard = '2029-01-09' }
            20348 = @{ Release = '2022';    EolStandard = '2031-10-14' }
            25398 = @{ Release = '23H2';    EolStandard = '2025-10-24' }
            26100 = @{ Release = '2025';    EolStandard = '2034-10-10' }
        }
    }
}

function Get-OSSupportStatus {
    <#
    .SYNOPSIS
        Evalue le statut de support de la version de Windows detectee.
    .PARAMETER Online
        Interroge l'API publique endoflife.date pour obtenir des dates de fin de
        support a jour. Desactive par defaut : l'audit n'emet aucune requete
        reseau sans demande explicite. En cas d'echec, le referentiel local
        embarque est utilise et la source est indiquee dans le resultat.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]$OSInfo,
        [switch]$Online,
        [int]$TimeoutSec = 10,

        # Delai avant fin de support a partir duquel une alerte est levee
        [int]$WarningWindowDays = 180
    )

    if (-not $OSInfo) { $OSInfo = Get-OSVersionInfo }

    $baseline = Get-OSSupportBaseline
    $table = if ($OSInfo.IsServer) { $baseline.Server } else { $baseline.Client }

    $eolDate = $null
    $release = $OSInfo.ReleaseLabel
    $source = "referentiel local (mis a jour le $($baseline.AsOf.ToString('yyyy-MM')))"

    # --- 1. Consultation en ligne (optionnelle) ------------------------------
    if ($Online) {
        $onlineEol = Get-OSSupportDateOnline -OSInfo $OSInfo -TimeoutSec $TimeoutSec
        if ($onlineEol) {
            $eolDate = $onlineEol.EndOfLife
            if ($onlineEol.Release) { $release = $onlineEol.Release }
            $source = "endoflife.date (cycle $($onlineEol.Cycle))"
        }
    }

    # --- 2. Referentiel local -------------------------------------------------
    if (-not $eolDate -and $table.ContainsKey($OSInfo.Build)) {
        $entry = $table[$OSInfo.Build]
        if (-not $release) { $release = $entry.Release }

        $key = 'EolStandard'
        if ($OSInfo.IsLTSC -and $entry.ContainsKey('EolLtsc')) { $key = 'EolLtsc' }
        elseif ($OSInfo.IsEnterprise -and $entry.ContainsKey('EolEnterprise')) { $key = 'EolEnterprise' }

        $eolDate = [datetime]$entry[$key]
    }

    # --- 3. Build absente du referentiel : positionnement relatif -------------
    if (-not $eolDate) {
        $knownBuilds = @($table.Keys | Sort-Object)
        $newest = $knownBuilds[-1]
        $oldest = $knownBuilds[0]

        if ($OSInfo.Build -gt $newest) {
            return [PSCustomObject]@{
                Status         = "PASS"
                IsSupported    = $true
                EndOfSupport   = $null
                DaysRemaining  = $null
                Release        = $release
                Source         = $source
                Comment        = "$($OSInfo.DisplayName) (build $($OSInfo.Build)) est plus recent que la version la plus recente du referentiel local (build $newest) : considere comme supporte."
                Recommendation = "Mettre a jour le referentiel de fin de support (Get-OSSupportBaseline) ou lancer l'audit avec -Online pour confirmer la date exacte."
            }
        }

        if ($OSInfo.Build -lt $oldest) {
            return [PSCustomObject]@{
                Status         = "FAIL"
                IsSupported    = $false
                EndOfSupport   = $null
                DaysRemaining  = $null
                Release        = $release
                Source         = $source
                Comment        = "$($OSInfo.DisplayName) (build $($OSInfo.Build)) est anterieur a la plus ancienne version du referentiel (build $oldest) : systeme hors support."
                Recommendation = "Migrer vers une version de Windows actuellement supportee : ce systeme ne recoit plus aucun correctif de securite."
            }
        }

        return [PSCustomObject]@{
            Status         = "UNKNOWN"
            IsSupported    = $null
            EndOfSupport   = $null
            DaysRemaining  = $null
            Release        = $release
            Source         = $source
            Comment        = "Build $($OSInfo.Build) absente du referentiel : statut de support indetermine."
            Recommendation = "Verifier manuellement le cycle de vie de cette version sur le site Microsoft Lifecycle."
        }
    }

    # --- 4. Evaluation --------------------------------------------------------
    $daysRemaining = [int]($eolDate - (Get-Date)).TotalDays

    if ($daysRemaining -lt 0) {
        $status = "FAIL"
        $comment = "$($OSInfo.DisplayName) est hors support depuis le $($eolDate.ToString('yyyy-MM-dd')) ($([Math]::Abs($daysRemaining)) jours)."
        $reco = "Migrer sans delai vers une version supportee : ce systeme ne recoit plus de correctifs de securite."
    }
    elseif ($daysRemaining -le $WarningWindowDays) {
        $status = "WARNING"
        $comment = "$($OSInfo.DisplayName) atteint sa fin de support le $($eolDate.ToString('yyyy-MM-dd')) (dans $daysRemaining jours)."
        $reco = "Planifier la montee de version avant le $($eolDate.ToString('yyyy-MM-dd'))."
    }
    else {
        $status = "PASS"
        $comment = "$($OSInfo.DisplayName) est supporte jusqu'au $($eolDate.ToString('yyyy-MM-dd')) ($daysRemaining jours restants)."
        $reco = "Maintenir le systeme a jour et suivre le calendrier de fin de support."
    }

    return [PSCustomObject]@{
        Status         = $status
        IsSupported    = ($daysRemaining -ge 0)
        EndOfSupport   = $eolDate
        DaysRemaining  = $daysRemaining
        Release        = $release
        Source         = $source
        Comment        = $comment
        Recommendation = $reco
    }
}

function Get-OSSupportDateOnline {
    <#
    .SYNOPSIS
        Recupere la date de fin de support depuis l'API publique endoflife.date.
    .DESCRIPTION
        Emet une requete HTTPS GET sans authentification et sans transmettre
        d'information sur la machine auditee. Renvoie $null si l'API est
        injoignable ou si aucun cycle ne correspond, afin que l'appelant
        retombe sur le referentiel local.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]$OSInfo,
        [int]$TimeoutSec = 10
    )

    $endpoint = if ($OSInfo.IsServer) {
        'https://endoflife.date/api/windows-server.json'
    } else {
        'https://endoflife.date/api/windows.json'
    }

    try {
        $cycles = Invoke-RestMethod -Uri $endpoint -TimeoutSec $TimeoutSec -ErrorAction Stop
    }
    catch {
        Write-Verbose "Consultation de endoflife.date impossible : $($_.Exception.Message)"
        return $null
    }

    # Correspondance par numero de build : le champ "latest" vaut "10.0.<build>.<ubr>"
    $match = $cycles | Where-Object { "$($_.latest)" -match "^10\.0\.$($OSInfo.Build)(\.|$)" }

    # A defaut, correspondance par version commerciale (24H2, 22H2...) en
    # respectant le suffixe de canal : -w = Famille/Pro, -e = Entreprise/Education
    if (-not $match -and $OSInfo.ReleaseLabel) {
        $suffix = if ($OSInfo.IsEnterprise) { 'e' } else { 'w' }
        $match = $cycles | Where-Object { "$($_.cycle)".ToLower() -match "$($OSInfo.ReleaseLabel.ToLower())-$suffix$" }
        if (-not $match) {
            $match = $cycles | Where-Object { "$($_.cycle)".ToLower() -match "^$($OSInfo.ReleaseLabel.ToLower())$" }
        }
    }

    $entry = @($match) | Select-Object -First 1
    if (-not $entry) { return $null }

    # eol vaut soit une date, soit un booleen (false = encore supporte)
    $eol = "$($entry.eol)"
    $eolDate = $null
    if ($eol -match '^\d{4}-\d{2}-\d{2}$') { $eolDate = [datetime]$eol }
    elseif ($eol -eq 'False' -or $eol -eq 'false') { $eolDate = (Get-Date).AddYears(1) }
    else { return $null }

    return [PSCustomObject]@{
        Cycle      = "$($entry.cycle)"
        Release    = "$($entry.cycle)"
        EndOfLife  = $eolDate
    }
}
