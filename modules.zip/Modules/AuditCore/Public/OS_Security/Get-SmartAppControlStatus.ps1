function Get-SmartAppControlStatus {
    [CmdletBinding()]
    param()

    $policyPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy'
    $val = (Get-ItemProperty -Path $policyPath -Name 'VerifiedAndReputablePolicyState' -ErrorAction SilentlyContinue).VerifiedAndReputablePolicyState

    switch ($val) {
        0 { $mode = 'Off' }
        1 { $mode = 'On' }
        2 { $mode = 'Evaluation' }
        $null { $mode = 'NotConfigured' }
        default { $mode = "Unknown ($val)" }
    }

    # Statut : SAC actif (On) = PASS ; mode Evaluation = WARNING ;
    # desactive / non configure = WARNING (SAC n'est disponible que sur les
    # installations propres recentes de Windows 11) ; valeur inconnue = UNKNOWN.
    $status = switch ($val) {
        1 { 'PASS' }
        2 { 'WARNING' }
        0 { 'WARNING' }
        $null { 'WARNING' }
        default { 'UNKNOWN' }
    }

    $SmartAppState = [pscustomobject]@{

        Status         = $status
        SmartApp_State = $mode

    }

    Return $SmartAppState

}

