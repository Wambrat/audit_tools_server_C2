<#
.SYNOPSIS
    Audite la politique de mot de passe locale et de verrouillage de compte.

.DESCRIPTION
    Utilise l'outil natif 'secedit' pour exporter la configuration de securite
    locale et la compare aux recommandations de l'ANSSI :
    - Longueur minimale (12 caracteres, 15 recommande).
    - Complexite activee.
    - Verrouillage de compte configure (3 tentatives recommandees).

    N'est pertinente que sur une machine hors domaine : sur une machine jointe,
    la politique effective est celle du domaine (controles AD-13 a AD-16).

.OUTPUTS
    PSCustomObject, ou $null si la politique n'a pas pu etre lue.
#>
function Get-PolPassAudit {
    [CmdletBinding()]
    param()

    process {
        # Fichier temporaire dans le repertoire temporaire de l'utilisateur :
        # un chemin relatif dependrait du repertoire courant de l'appelant et
        # faisait echouer l'export selon l'endroit d'ou l'audit etait lance.
        $tempFile = Join-Path -Path $env:TEMP -ChildPath "secpol_audit_$([guid]::NewGuid().ToString('N')).cfg"

        # Recommandations (base de connaissances ANSSI)
        $Recos = @{
            MinLengthStandard = 12
            MinLengthAdmin    = 15
            LockoutThreshold  = 3
        }

        try {
            # 1. Export de la configuration de securite locale
            $seceditOutput = & SecEdit.exe /export /cfg "$tempFile" /quiet 2>&1

            if (-not (Test-Path -LiteralPath $tempFile)) {
                throw "SecEdit n'a pas produit de fichier d'export ($seceditOutput). L'audit doit etre execute avec des privileges administrateur."
            }

            $content = Get-Content -Path $tempFile -Encoding Unicode -Raw

            # 2. Extraction des valeurs
            # Chaque motif est teste independamment : $Matches conserve sinon le
            # resultat du motif precedent et produit une valeur erronee.
            $currentMinLength = if ($content -match "MinimumPasswordLength\s*=\s*(\d+)") { [int]$Matches[1] } else { $null }
            $currentComplexity = if ($content -match "PasswordComplexity\s*=\s*(\d+)") { [int]$Matches[1] } else { $null }
            $currentLockout = if ($content -match "LockoutBadCount\s*=\s*(\d+)") { [int]$Matches[1] } else { $null }

            if ($null -eq $currentMinLength -and $null -eq $currentComplexity -and $null -eq $currentLockout) {
                throw "Aucun parametre de politique de mot de passe trouve dans l'export SecEdit."
            }

            # 3. Analyse de conformite
            # --- Longueur ---
            # Le seuil depend de la politique attendue, pas du niveau de
            # privilege du processus d'audit.
            if ($null -eq $currentMinLength) {
                $statusLength = "UNKNOWN"
                $msgLength = "Longueur minimale non lisible dans l'export SecEdit."
            }
            elseif ($currentMinLength -ge $Recos.MinLengthAdmin) {
                $statusLength = "PASS"
                $msgLength = "Conforme et renforce : $currentMinLength caracteres (>= $($Recos.MinLengthAdmin))."
            }
            elseif ($currentMinLength -ge $Recos.MinLengthStandard) {
                $statusLength = "PASS"
                $msgLength = "Conforme : $currentMinLength caracteres (>= $($Recos.MinLengthStandard)). Porter a $($Recos.MinLengthAdmin) pour les comptes d'administration."
            }
            else {
                $statusLength = "FAIL"
                $msgLength = "NON CONFORME : longueur minimale de $currentMinLength caracteres, inferieure au minimum ANSSI ($($Recos.MinLengthStandard))."
            }

            # --- Complexite ---
            switch ($currentComplexity) {
                1 {
                    $statusComplexity = "PASS"
                    $msgComplexity = "Complexite activee."
                }
                0 {
                    $statusComplexity = "FAIL"
                    $msgComplexity = "RISQUE : la complexite des mots de passe n'est pas exigee."
                }
                Default {
                    $statusComplexity = "UNKNOWN"
                    $msgComplexity = "Etat de la complexite non lisible dans l'export SecEdit."
                }
            }

            # --- Verrouillage de compte ---
            if ($null -eq $currentLockout) {
                $statusLockout = "UNKNOWN"
                $msgLockout = "Seuil de verrouillage non lisible dans l'export SecEdit."
            }
            elseif ($currentLockout -eq 0) {
                $statusLockout = "FAIL"
                $msgLockout = "RISQUE : le verrouillage de compte est desactive, les attaques par force brute ne sont pas entravees."
            }
            elseif ($currentLockout -le $Recos.LockoutThreshold) {
                $statusLockout = "PASS"
                $msgLockout = "Protection active ($currentLockout echec(s) avant blocage)."
            }
            else {
                $statusLockout = "WARNING"
                $msgLockout = "Seuil eleve ($currentLockout tentatives). Le reduire a $($Recos.LockoutThreshold) pour limiter les essais avant blocage."
            }

            $statuses = @($statusLength, $statusComplexity, $statusLockout)
            $globalStatus = if ($statuses -contains "FAIL") { "FAIL" }
                            elseif ($statuses -contains "WARNING") { "WARNING" }
                            elseif ($statuses -contains "UNKNOWN") { "UNKNOWN" }
                            else { "PASS" }

            return [PSCustomObject]@{
                Check            = "Password Policy"
                Status           = $globalStatus

                MinLengthVal     = $currentMinLength
                MinLengthStatus  = $statusLength
                MinLengthReco    = $msgLength

                ComplexityVal    = $currentComplexity
                ComplexityStatus = $statusComplexity
                ComplexityReco   = $msgComplexity

                LockoutVal       = $currentLockout
                LockoutStatus    = $statusLockout
                LockoutReco      = $msgLockout

                GlobalStatus     = $globalStatus
                Timestamp        = (Get-Date)
            }
        }
        catch {
            # Renvoie $null : l'appelant conclut alors a un controle non evalue.
            # Renvoyer un objet porteur d'une propriete "Status" ecraserait le
            # champ "status" de la section d'audit lors de la fusion.
            Write-Warning "Erreur audit Politique Mot de Passe : $($_.Exception.Message)"
            return $null
        }
        finally {
            if (Test-Path -LiteralPath $tempFile) {
                Remove-Item -LiteralPath $tempFile -Force -ErrorAction SilentlyContinue
            }
        }
    }
}
